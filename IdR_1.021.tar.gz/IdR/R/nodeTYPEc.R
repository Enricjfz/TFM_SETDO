nodeTYPEc <-
function () 
{
    return(nodeTYPE[5:8])
}
