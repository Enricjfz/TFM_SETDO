nodeTYPEd <-
function () 
{
    return(nodeTYPE[1:4])
}
