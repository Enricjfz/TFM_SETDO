names.id <-
function (id, index, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<names.id")
    NAMES <- c()
    for (i in 1:length(index)) {
        if ((index[i] > 0) && (index[i] <= length(id))) {
            NAMES <- c(NAMES, id[index[i]][[1]]$name)
        }
        else {
            cat("Error, names.id, OVF index node: ", index[i], 
                "\n")
            print(str(id))
            print(index)
            stop("Error. names.id")
        }
    }
    if (trz.definition) 
        cat("-names.id>")
    return(NAMES)
}
