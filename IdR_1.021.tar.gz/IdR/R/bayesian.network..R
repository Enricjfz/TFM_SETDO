bayesian.network. <-
function (Nodes, Names = NULL, Probability = TRUE, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<bayesian.network.")
    if (length(Nodes) < length(names(Nodes))) {
        if (trz.definition) 
            cat("\nBayesian Network: ", "\nNodes: ", length(Nodes), 
                "\n")
        if (length(Names) == 0) 
            Names <- names(Nodes)
        bn <- list()
        for (i in 1:length(Nodes)) {
            node <- Nodes[i]
            if (trz.definition) 
                print(node)
            if (!is.chance(node[[1]])) {
                print(node)
                stop("not chance node in BN")
            }
            names(node) <- Names[i]
            bn <- c(bn, node[[1]])
        }
    }
    else bn <- Nodes
    bn <- check.rr(bn)
    if (Probability) 
        bn <- check.mx(bn, EPSILON = 9.9999999999999995e-08, 
            CALC = TRUE, trz.probability = trz.definition)
    if (trz.definition) 
        cat("Bayesian Network: OK\n")
    if (trz.definition) 
        cat("-bayesian.network.>")
    invisible(bn)
}
