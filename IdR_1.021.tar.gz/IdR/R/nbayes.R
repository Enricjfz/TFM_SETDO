nbayes <-
function (tab0, class.name = NULL, laplace.correction = FALSE, 
    trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# nbayes: \n")
    t0 <- proc.time()
    namevars <- names(tab0)
    cat("#", namevars, "\n")
    yfit.levels <- levels(factor(tab0[, class.name]))
    for (i in 1:length(namevars)) {
        ll <- length(levels(factor(tab0[, i])))
        if (namevars[i] == class.name) {
            cat("\n#n#  Node ", namevars[i], "  Values ", levels(factor(tab0[, 
                i])), "  length( Values) ", ll, "\n")
            ll <- marginal.NODE(tab0, i, 1e-25, laplace.correction, 
                trz.probability)
        }
        if (namevars[i] != class.name) {
            cat("\n#n#  Node ", namevars[i], "  Values ", levels(factor(tab0[, 
                i])), "  length( Values) ", ll, "\n")
            pot <- c()
            if (class.node) {
                if (length(yfit.levels) < 2) 
                  stop("nbayes yfit < 2.")
                for (k in 1:length(yfit.levels)) {
                  k.dat <- tab0[tab0$yfit == yfit.levels[k], 
                    c(i)]
                  if (length(k.dat) == 0) {
                    k.dat <- data.frame(rep(1/ll, ll))
                    names(k.dat) <- namevars[i]
                  }
                  if (laplace.correction) 
                    pot <- c(pot, table(k.dat + 1)/(length(k.dat) + 
                      length(levels(tab0[, i]))))
                  else pot <- c(pot, table(k.dat)/length(k.dat))
                }
                NODE <- node(Type = "CHANCE", Name = namevars[i], 
                  Values = levels(factor(tab0[, i])), Preds = c(class.name), 
                  Pots = matrix(data = pot, nrow = length(levels(factor(tab0$yfit))), 
                    ncol = ll, byrow = TRUE, dimnames = NULL))
                cat(",\n\n")
                dump.chance(NODE)
            }
            if (ll < 2) {
                marginal.NODE(tab0, i, 1e-25, laplace.correction, 
                  coma = TRUE, trz.probability)
            }
        }
    }
    if (trz.probability) 
        cat("# OK\n")
    cat("# nbayes in ", (proc.time() - t0)[1], " seconds.\n")
    return()
}
