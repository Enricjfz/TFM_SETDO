INDEP.COND_ <-
function () 
{
    return(0)
}
