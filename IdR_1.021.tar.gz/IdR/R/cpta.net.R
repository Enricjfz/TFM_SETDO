cpta.net <-
function (net, name = "netname", node = 0, NumClusters = 2, EU.KL = "EU", 
    trz.probability = FALSE) 
{
    if (!trz.probability) 
        cat("<cpta.net ", NumClusters, "  clusters\n")
    NUMCLUSTERS <- max(2, NumClusters)
    if (node == 0) {
        for (i in 1:length(net)) {
            node.C <- net[i][[1]]
            if (is.chance(node.C) & length(node.C$preds) > 1) {
                pam.cpd <- pam(node.C$pots, NUMCLUSTERS, cluster.only = FALSE)
                if (trz.probability) 
                  print(pam.cpd)
                for (k in 1:NUMCLUSTERS) {
                  ik <- which(pam.cpd$clustering == k)
                  node.C$pots[ik, ] = rep(pam.cpd$medoids[k, 
                    ], each = length(ik))
                }
                if (trz.probability) 
                  print(node.C)
                net[index.id(net, node.C$name)][[1]] <- node.C
            }
        }
    }
    else {
        node.C <- net[node][[1]]
        if (is.chance(node.C) & length(node.C$preds) > 1) {
            if (EU.KL == "EU") {
                pam.cpd <- pam(cbind(node.C$pots, mdgrid(net, 
                  node.C, kbm2lcoded = TRUE, clustercoded = TRUE)), 
                  diss = FALSE, NUMCLUSTERS, metric = "euclidean", 
                  cluster.only = FALSE)
            }
            else {
                pam.cpd <- pam(EU.KL, diss = TRUE, NUMCLUSTERS, 
                  cluster.only = FALSE)
            }
            if (trz.probability) 
                print(pam.cpd)
            for (k in 1:NUMCLUSTERS) {
                ik <- which(pam.cpd$clustering == k)
                if (EU.KL == "EU") {
                  node.C$pots[ik, ] = rep(pam.cpd$medoids[k, 
                    1:length(node.C$values)], each = length(ik))
                }
                else {
                  node.C$pots[ik, ] = rep(node.C$pots[pam.cpd$medoids[k], 
                    ], each = length(ik))
                }
            }
            if (trz.probability) 
                print(node.C)
            net[index.id(net, node.C$name)][[1]] <- node.C
        }
    }
    if (trz.probability) 
        cat("...cpta.net\n")
    return(net)
}
