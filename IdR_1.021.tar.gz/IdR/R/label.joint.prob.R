label.joint.prob <-
function (tab0, labels, trz.probability = FALSE) 
{
    label.str <- function(str) {
        LBL <- paste(str[1], sep = "")
        if (length(str) == 1) 
            return(LBL)
        for (j in 2:length(str)) LBL <- paste(LBL, "<", str[j], 
            sep = "")
        return(LBL)
    }
    data1 <- which(tab0[1, 1:labels] == 1)
    if (length(data1) == 0) 
        LABEL <- c("")
    else LABEL <- c(label.str(data1))
    for (i in 2:(dim(tab0)[1])) {
        data1 <- which(tab0[i, 1:labels] == 1)
        if (length(data1) == 0) 
            LABEL <- c(LABEL, "")
        else LABEL <- c(LABEL, label.str(data1))
    }
    tab0 <- data.frame(LBL = LABEL)
    tab0$LBL <- as.ordered(tab0$LBL)
    return(tab0)
}
