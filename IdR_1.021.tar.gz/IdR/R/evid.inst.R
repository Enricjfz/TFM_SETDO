evid.inst <-
function (id, evid, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("EVID.INST ")
    while (length(evid) > 0) {
        name <- evid[1]
        value <- evid[2]
        node <- ann(id, name)
        if (esta(value, node$values)) {
            cat("evid.inst   node --- ", node$name, "   value --- ", 
                value, "\n")
            id <- inst.potential(id, node, value)
            I <- index.id(id, node$name)
            for (j in 1:length(id)) id[j][[1]]$preds <- remove.name(id[j][[1]]$preds, 
                node$name)
            cat("I: ", I, "\n")
            id <- id[-I]
            print(names(id))
            evid <- evid[c(-1, -2)]
        }
        else {
            cat("name node:   ", name, "\n")
            cat("values:      ", node$values, "\n")
            cat("value node:  ", value, "\n")
            stop("name node?, value node?")
        }
    }
    if (trz.evaluation) 
        cat("EVID.INST: OK\n")
    return(id)
}
