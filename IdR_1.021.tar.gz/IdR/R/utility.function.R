utility.function <-
function (dimensions, params, model = "runif", trz.probability = FALSE) 
{
    if (model == "IctNeo2HGM") {
        k <- params[1]
        k1 <- params[2]
        k2 <- params[3]
        kx2 <- params[6]
        kx3 <- params[7]
        k3 <- params[4]
        k4 <- params[5]
        kx5 <- params[8]
        kx6 <- params[9]
        data.pots <- c()
        for (i1 in 0:(dimensions[1] - 1)) for (i2 in 0:(dimensions[2] - 
            1)) for (i3 in 0:(dimensions[3] - 1)) for (i4 in 0:(dimensions[4] - 
            1)) for (i5 in 0:(dimensions[5] - 1)) for (i6 in 0:(dimensions[6] - 
            1)) {
            U <- k1 * u1(i1) + k2 * u2(i2, i3) + k3 * u3(i3) + 
                k4 * u4(i5, i6) + k * (k1 * u1(i1) * k2 * u2(i2, 
                i3) + k1 * u1(i1) * k3 * u3(i3) + k1 * u1(i1) * 
                k4 * u4(i5, i6) + k2 * u2(i2, i3) * k3 * u3(i3) + 
                k2 * u2(i2, i3) * k4 * u4(i5, i6) + k3 * u3(i3) * 
                k4 * u4(i5, i6)) + k^2 * (k1 * u1(i1) * k2 * 
                u2(i2, i3) * k3 * u3(i3) + k1 * u1(i1) + k2 * 
                u2(i2, i3) * k4 * u4(i5, i6) + k2 * u2(i2, i3) * 
                k3 * u3(i3) * k4 * u4(i5, i6) + k1 * u1(i1) * 
                k3 * u3(i3) * k4 * u4(i5, i6)) + k^3 * (k1 * 
                u1(i1) * k2 * u2(i2, i3) * k3 * u3(i3) * k4 * 
                u4(i5, i6))
            data.pots <- c(data.pots, U)
        }
        return(data.pots)
    }
    if (trz.probability) 
        cat("utility.function ")
    if (model == "runif") {
        data.pots <- runif(prod(dimensions), 0, 1)
    }
    if (trz.probability) 
        cat("utility.function: OK\n")
    return(data.pots)
}
