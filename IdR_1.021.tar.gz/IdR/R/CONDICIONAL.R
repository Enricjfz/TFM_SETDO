CONDICIONAL <-
function () 
{
    return(1)
}
