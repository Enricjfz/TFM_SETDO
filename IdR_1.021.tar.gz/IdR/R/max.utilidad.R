max.utilidad <-
function (id, node, node.U, Calc = TRUE, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("max.utilidad ")
    if (Calc) {
        node.U <- rotacion.pots(id, node.U, c(node$name))
        nv <- length(node$values)
        max.pots <- c()
        for (i in 1:(length(node.U$pots)/nv)) max.pots <- c(max.pots, 
            max(node.U$pots[(1 + (nv * (i - 1))):(nv * i)]))
        node.U$pots <- matrix(data = max.pots, ncol = 1, byrow = TRUE, 
            dimnames = list(NULL, c("utility")))
        if (length(node.U$preds) > 1) 
            node.U$preds <- node.U$preds[1:(length(node.U$preds) - 
                1)]
        else node.U$preds <- c()
    }
    else node.U$preds <- remove.name(node.U$preds, node$name)
    if (trz.probability) 
        cat("max.utilidad: OK\n")
    return(node.U)
}
