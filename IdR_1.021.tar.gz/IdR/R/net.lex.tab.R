net.lex.tab <-
function (net) 
{
    max.dom.val <- 0
    for (i in 1:length(net)) if (max.dom.val < length(net[i][[1]]$values)) 
        max.dom.val <- length(net[i][[1]]$values)
    tab0 <- data.frame(rep(net[1][[1]]$values, max.dom.val))
    for (i in 2:length(net)) tab0 <- cbind(tab0, rep(net[i][[1]]$values, 
        max.dom.val))
    names(tab0) <- names(net)
    invisible(tab0)
}
