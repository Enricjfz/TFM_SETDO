xbayes <-
function (tab0, noise, laplace.correction = FALSE, time.out = 300, 
    trz.probability = FALSE) 
{
    require(entropy, lib.loc = "../R/lib", quietly = TRUE)
    require(foreach, lib.loc = "../R/lib", quietly = TRUE)
    require(doSNOW, lib.loc = "../R/lib", quietly = TRUE)
    if (trz.probability) 
        cat("# xbayes: \n")
    min.mdl.1 <- 100000000
    min.mdl.2 <- 100000000
    mdl.net <- NULL
    best.MADY <- NULL
    MatrixAdyacency <- NULL
    tab0.p <- raw.joint.prob(tab0 = tab0, trz.probability = trz.probability)
    wmady <- matrix(data = rep(0, (dim(tab0)[2])^2), nrow = dim(tab0)[2])
    for (i in 1:dim(tab0)[2]) for (j in 1:dim(tab0)[2]) if (i != 
        j) 
        wmady[i, j] <- as.vector(entropy.plugin(table(tab0[, 
            c(i)]))) + as.vector(entropy.plugin(table(tab0[, 
            c(j)]))) - entropy.plugin(raw.joint.prob(tab0[, c(i, 
            j)])$fr)
    EPSILON = mean(wmady)/2
    cat("# wmady <- mi( tab0)\n")
    for (i in 1:dim(tab0)[2]) cat("#", wmady[i, ], "\n")
    cat("\n# max(mi2)", max(wmady), "  mean(mi2)", mean(wmady), 
        "  min(mi2)", min(wmady), "\n")
    N.MODELS <- 2 * dim(tab0)[1]
    attperms <- sample(dim(tab0)[2])
    for (i in 2:N.MODELS) attperms <- rbind(attperms, sample(dim(tab0)[2]))
    t0 <- proc.time()
    MODELS <- foreach(model = 1:N.MODELS, .combine = "rbind", 
        .export = c("c.c.m", "lbn.structure", "lbn.probability", 
            "KLD", "MDL")) %dopar% {
        attperm <- attperms[model][[1]]
        MatrixAdyacency <- matrix(data = rep(0, (dim(tab0)[2])^2), 
            nrow = dim(tab0)[2], ncol = dim(tab0)[2], dimnames = list(1:dim(tab0)[2], 
                1:dim(tab0)[2]))
        for (att in attperm) {
            windex <- order(wmady[, att], decreasing = FALSE)
            for (indx in 1:length(windex)) {
                if (abs(wmady[windex[indx], att]) > EPSILON) 
                  MatrixAdyacency[windex[indx], att] <- 1
                if (c.c.m(MatrixAdyacency)) 
                  MatrixAdyacency[windex[indx], att] <- 0
                if (sum(MatrixAdyacency[, att]) >= 3) 
                  break
            }
        }
        if (c.c.m(MatrixAdyacency)) 
            stop("c.c.m( MatrixAdyacency)  ", MatrixAdyacency)
        net <- lbn.structure(tab0, MatrixAdyacency, trz.probability = trz.probability)
        net <- lbn.probability(x = tab0, net = net, laplace.correction = laplace.correction, 
            trz.probability = trz.probability)
        data.frame(kld = KLD(data = tab0, data.p = tab0.p, net, 
            trz.probability = trz.probability), mdl = MDL(net, 
            trz.probability = trz.probability), MA = t(as.vector(MatrixAdyacency)))
    }
    MODEL <- 0
    bestModel <- 0
    for (i in 1:dim(MODELS)[1]) {
        MODEL <- MODEL + 1
        model <- MODELS[i, ]
        if ((model[1] <= min.mdl.2)) {
            if ((model[2] <= min.mdl.1)) {
                min.mdl.1 <- as.numeric(model[2])
                min.mdl.2 <- as.numeric(model[1])
                best.MADY <- matrix(data = as.numeric(model[3:dim(MODELS)[2]]), 
                  nrow = dim(tab0)[2])
                cat("\n# network", "xbayes --- lbn.stress.OK  mdl.1: ", 
                  min.mdl.1, "   mdl.2: ", min.mdl.2, "  ***\n")
                bestModel <- MODEL
            }
            else cat("# num.models:", MODEL, "\n")
        }
    }
    MatrixAdyacency <- best.MADY
    cat("\n# best network", "xbayes --- lbn.stress.OK  mdl.1: ", 
        min.mdl.1, "   mdl.2: ", min.mdl.2, "  *******\n")
    net.struct <- lbn.structure(tab0, MatrixAdyacency, trz.probability = trz.probability)
    net <- lbn.probability(x = tab0, net = net.struct, laplace.correction = laplace.correction, 
        trz.probability = trz.probability)
    dump.netR(net, "", SINK = FALSE, trz.primitive = trz.probability)
    cat("\n# xbayes  models:", MODEL, "   MODEL/SEGS:", MODEL/as.numeric(((proc.time() - 
        t0)[1])), "\n")
    cat("\n# xbayes in ", (proc.time() - t0)[1], " seconds.\n")
    if (trz.probability) 
        cat("# xbayes OK\n")
    if (c.c.m(MatrixAdyacency)) 
        stop("MatrixAdyacency", MatrixAdyacency)
    return(min.mdl.1 * min.mdl.2)
}
