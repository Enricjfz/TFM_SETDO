network.type <-
function (net, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<network.type>")
    for (i in 1:length(net)) {
        if (is.utility(net[i][[1]])) {
            return("Influence diagram")
        }
    }
    for (i in 1:length(net)) {
        if (is.decision(net[i][[1]])) {
            stop("decision node in BN or utility node is missing")
        }
    }
    return("Bayesian network")
}
