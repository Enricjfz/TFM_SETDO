idr.input.id <-
function (bar = "Yes") 
{
    if (bar == "Yes") 
        return("models/IDmodels/")
    else return("models/IDmodels")
}
