suma.utilidad <-
function (pots, nval, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("<suma.utilidad")
    m <- length(pots[, 1])
    suma.pots <- matrix(data = c(0), nrow = (m/nval), ncol = 1, 
        byrow = TRUE, dimnames = NULL)
    for (i in 1:(m/nval)) {
        suma.pots[i, ] <- sum(pots[(1 + (nval * (i - 1))):(nval * 
            i), ])
    }
    if (trz.probability) 
        cat("-suma.utilidad>\n")
    return(suma.pots)
}
