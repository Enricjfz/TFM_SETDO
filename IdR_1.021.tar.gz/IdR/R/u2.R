u2 <-
function (y2, y3) 
{
    return(ux2(y2) + ux3(y3))
}
