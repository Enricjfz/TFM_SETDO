Indx <-
function (id, preds, preds.values, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("<Indx")
    indx.atts <- c()
    for (i in 1:length(preds.values)) {
        indx.atts <- c(indx.atts, which(id[preds[i]][[1]]$values == 
            preds.values[i]))
    }
    if (trz.primitive) 
        cat("-Indx>")
    return(indx.atts)
}
