pr <-
function (id, name, value, values, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("pr ")
    node <- ann(id, name)
    i <- which(node$values == value)
    v <- fd(id, node$weights, node$preds, values)[i]
    if (trz.probability) 
        cat("pr: OK\n")
    return(v)
}
