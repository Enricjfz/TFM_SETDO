check.mx <-
function (id, node = 0, EPSILON = 9.9999999999999995e-08, CALC = TRUE, 
    trz.probability = FALSE) 
{
    std.potential <- function(pots, trz.probability = FALSE) {
        if (trz.probability) {
            cat("<std.potential>\n")
            print(pots)
        }
        if (CALC) 
            if (length(pots[1, ]) < 1) 
                stop("length( pots[ 1, ]) < 1")
        if (CALC) 
            if (length(pots[, 1]) <= 0) 
                stop("length( pots[ , 1]) <= 0")
        if (length(pots[1, ]) >= 2) 
            for (i in 1:length(pots[, 1])) {
                if (Re(sum(pots[i, ])) <= 0) {
                  cat(sum(pots[i, ]), "\n")
                  stop("sum(pots[ i,] <= 0")
                }
                pots[i, ] <- Re(pots[i, ])/Re(sum(pots[i, ]))
            }
        if (CALC) 
            if (length(pots[1, ]) == 1) {
                pots <- pots - min(pots)
                pots <- pots/max(pots)
            }
        if (trz.probability) 
            print(pots)
        return(pots)
    }
    pr.epsilon <- function(id, Epsilon = 1e-25, CALC = TRUE, 
        trz.probability = FALSE) {
        if (trz.probability) 
            cat("pr.epsilon ")
        if (CALC) {
            for (i in 1:length(id)) {
                if (is.chance(id[i][[1]])) {
                  for (j in 1:length(id[i][[1]]$pots[, 1])) {
                    id[i][[1]]$pots[j, ] <- id[i][[1]]$pots[j, 
                      ] + Epsilon
                  }
                  id[i][[1]]$pots <- std.potential(id[i][[1]]$pots, 
                    trz.probability = trz.probability)
                }
            }
        }
        if (trz.probability) 
            cat("pr.epsilon: OK\n")
        return(id)
    }
    sz.check <- 4096
    error <- FALSE
    if (trz.probability) 
        cat("\n#  check.mx ")
    print(CALC)
    if (CALC) {
        nodeset <- 1:length(id)
        if (node != 0) 
            if (node >= 1 & node <= length(id)) {
                nodeset <- node
                if (trz.probability) 
                  cat("#  ", id[node][[1]]$name, "\n")
            }
            else stop("!( node >= 1 & node <= length( id)).")
        for (i in nodeset) {
            if (is.matrix(id[i][[1]]$pots)) 
                if (!is.decision(id[i][[1]])) {
                  if (!is.utility(id[i][[1]])) {
                    if (!is.marginal(id[i][[1]])) {
                      error <- check.conditional.node(id, id[i][[1]], 
                        EPSILON, error)
                      if (error) 
                        id[i][[1]]$pots <- std.potential(id[i][[1]]$pots, 
                          trz.probability = trz.probability)
                    }
                    else {
                      error <- check.marginal.node(id, id[i][[1]], 
                        EPSILON, error)
                      if (error) 
                        id[i][[1]]$pots <- std.potential(id[i][[1]]$pots, 
                          trz.probability = trz.probability)
                    }
                    if (length(id[i][[1]]$mpot) > 1) {
                      if (sum(id[i][[1]]$mpot) - 1 > EPSILON) {
                        cat("\nNode: ", id[i][[1]]$name, "\n")
                        cat("marg.pot not sum.1.0", "\n")
                        error <- TRUE | error
                      }
                    }
                  }
                  else {
                    if (pots.size(id, id[i][[1]]) != length(id[i][[1]]$pots)) {
                      cat("\nNode: ", i, id[i][[1]]$name, "\n")
                      cat("pots.size: ", pots.size(id, id[i][[1]]), 
                        "   length: ", length(id[i][[1]]$pots), 
                        "\n")
                      cat("utility.node not fit.sz", "\n")
                      error <- TRUE | error
                    }
                    else {
                      for (k in sample(1:(length(id[i][[1]]$pots)), 
                        min(sz.check, length(id[i][[1]]$pots)))) if (id[i][[1]]$pots[k] < 
                        0 | id[i][[1]]$pots[k] > 1) {
                        if (trz.probability) {
                          cat("\nNode: ", i, id[i][[1]]$name, 
                            "\n")
                          cat("utility.node not normalized on (0.0,1.0)", 
                            "\n")
                        }
                        error <- FALSE | error
                      }
                      id[i][[1]]$pots <- std.potential(id[i][[1]]$pots, 
                        trz.probability = trz.probability)
                    }
                  }
                }
        }
    }
    id <- pr.epsilon(id, CALC = CALC, trz.probability = trz.probability)
    if (trz.probability) 
        cat("check.mx: OK\n")
    return(id)
}
