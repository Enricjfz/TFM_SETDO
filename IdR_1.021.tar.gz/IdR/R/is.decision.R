is.decision <-
function (node, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<is.decision>")
    return(node$type == "DECISION")
}
