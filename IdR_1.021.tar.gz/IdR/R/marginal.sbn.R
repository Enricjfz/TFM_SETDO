marginal.sbn <-
function (bn, tab0, ssz, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("marginal.sbn: ")
    bn.simu <- NULL
    feature.node <- NULL
    namevars <- names(tab0)
    for (i.name in 1:length(namevars)) {
        feature.node <- ann(bn, namevars[i.name], STOP = FALSE)
        if (length(feature.node) == 0) {
            if (length(bn.simu) == 0) 
                bn.simu <- data.frame(rep(tab0[1, i.name], ssz))
            else bn.simu <- cbind(bn.simu, rep(tab0[1, i.name], 
                ssz))
        }
        else {
            i.sample <- data.frame(sample(feature.node$values, 
                size = ssz, replace = TRUE, prob = as.vector(feature.node$pots)))
            if (length(bn.simu) == 0) 
                bn.simu <- data.frame(i.sample)
            else bn.simu <- cbind(bn.simu, i.sample)
        }
    }
    if (trz.probability) 
        cat("OK\n")
    return(bn.simu)
}
