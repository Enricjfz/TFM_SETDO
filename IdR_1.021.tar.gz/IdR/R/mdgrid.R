mdgrid <-
function (id, node, kbm2lcoded = TRUE, clustercoded = FALSE, 
    trz.tables = FALSE) 
{
    if (trz.tables) 
        cat("<mdgrid ")
    if (length(node$preds) >= 1) {
        preds <- node$preds
        wv <- weights.vector(id, preds, trz.probability = trz.tables)
        values0 <- ann(id, preds[1], trz.definition = trz.tables)$values
        roll <- rep(values0, length.out = wv[1] * length(values0), 
            each = wv[1])
        Grid <- data.frame(roll)
        if (length(preds) > 1) 
            for (i in 2:length(preds)) {
                values <- ann(id, preds[i], trz.definition = trz.tables)$values
                roll <- rep(values, length.out = wv[i] * length(values), 
                  each = wv[i])
                Grid <- data.frame(Grid, roll)
            }
        names(Grid) <- preds
        if (kbm2lcoded) {
            for (i in 1:length(Grid[1, ])) {
                Grid[, i] <- ordered(Grid[, i], levels = ann(id, 
                  preds[i], trz.definition = trz.tables)$values)
                Grid[, i] <- as.integer(Grid[, i]) - 1
            }
            if (clustercoded) {
                ClusterCode <- c()
                for (i in 1:length(preds)) {
                  values <- ann(id, preds[i], trz.definition = trz.tables)$values
                  ClusterCode <- c(ClusterCode, rep(0, length(values)))
                }
                GCC <- data.frame(t(ClusterCode))
                for (i in 1:length(Grid[, 1])) {
                  CCode <- ClusterCode
                  pcc <- 1
                  for (j in 1:length(preds)) {
                    values <- ann(id, preds[j], trz.definition = trz.tables)$values
                    CCode[pcc + length(values) - Grid[i, j] - 
                      1] <- 1
                    pcc <- pcc + length(values)
                  }
                  GCC <- rbind(GCC, CCode)
                }
                Grid <- GCC[2:length(GCC[, 1]), ]
            }
        }
        if (trz.tables) {
            print(Grid)
            cat("mdgrid: OK>\n")
        }
        return(Grid)
    }
    else return(NULL)
}
