idr.input.bn <-
function (bar = "Yes") 
{
    if (bar == "Yes") 
        return("models/BNmodels/")
    else return("models/BNmodels")
}
