minf <-
function (id, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<minf")
    MADY <- mady(id)
    c.c(id)
    MINF <- matrix(data = rep(INDEP.COND_(), length(id) * length(id)), 
        nrow = length(id), ncol = length(id), byrow = TRUE, dimnames = list(names(id), 
            names(id)))
    for (i in 1:length(id)) {
        for (j in 1:length(id)) if (i != j) {
            if (MADY[i, j] == CONDICIONAL()) 
                MINF[i, j] <- influence.node(id, id[i][[1]], 
                  id[j][[1]])
            if (MADY[i, j] == INFORMATIVO()) 
                MINF[i, j] <- 100
        }
    }
    if (trz.definition) 
        cat("-minf>")
    return(MINF)
}
