ux2 <-
function (y2) 
{
    return(-0.1108 + 1.111 * exp(-1.2529999999999999 * y2))
}
