conditional.expectation <-
function (id, node, node.U, Calc = TRUE, trz.probability = FALSE) 
{
    if (trz.probability) {
        cat("conditional.expectation ")
        cat("node.U$preds: ", node.U$preds, "\n")
    }
    if (Calc) {
        nv <- length(node$values)
        sz0 = length(node$pots[, 1]) * nv
        sz1 = length(node.U$pots[, 1])
        if (sz0 > sz1) {
            cat("name: ", node.U$name, "  preds: ", node.U$preds, 
                "  old.size: ", sz0, "  new.size: ", sz1, "\n")
            stop("sz0 > sz1")
        }
        node.U <- rotacion.pots(id, node.U, c(node$preds, node$name), 
            trz.probability = FALSE)
        new.pots <- node.U$pots[, 1] * matrix(data = rep(t(node$pots), 
            sz1/sz0), ncol = 1, byrow = TRUE, , dimnames = list(NULL, 
            c("probability")))[, 1]
        new.pots <- suma.utilidad(matrix(data = new.pots, ncol = 1, 
            byrow = TRUE, dimnames = list(NULL, c("utility"))), 
            nv)
        node.U$pots <- matrix(data = new.pots, ncol = 1, byrow = TRUE, 
            dimnames = list(NULL, c("utility")))
        if (length(node.U$preds) > 1) 
            node.U$preds <- node.U$preds[1:(length(node.U$preds) - 
                1)]
        else node.U$preds <- c()
    }
    else node.U$preds <- remove.name(node.U$preds, node$name, 
        trz.primitive = trz.probability)
    if (trz.probability) {
        cat("node.U$preds: ", node.U$preds, "\n")
        cat("conditional.expectation: OK\n")
    }
    return(node.U)
}
