barprob <-
function (net, filename = "net", node = 0, verbose = "NO", save = "YES", 
    trz.probability = FALSE) 
{
    pszW <- 8.75
    pszH <- 10.5
    if (trz.probability) 
        cat("barprob ")
    if (node <= 0) {
        if (save == "YES") 
            postscript(paste(idr.output.eval(), "barprob-", "net-", 
                filename, ".eps", sep = ""), horizontal = FALSE, 
                width = pszW, height = pszH)
        r <- min(5, round(sqrt(length(net))))
        c <- min(6, 1 + round(sqrt(length(net))))
        par(mfrow = c(r, c))
        for (i in 1:length(net)) if (is.chance(net[i][[1]])) 
            if (length(net[i][[1]]$mpot) > 1) {
                if (verbose == "YES") {
                  print(net[i][[1]]$name)
                  print(net[i][[1]]$mpot)
                }
                picture <- barplot(c(net[i][[1]]$mpot), main = net[i][[1]]$name, 
                  names.arg = c(net[i][[1]]$values), col = "light blue", 
                  ylim = c(0, 1))
            }
        dev.off()
    }
    else {
        if (save == "YES") 
            postscript(paste(idr.output.eval(), "barprob-", net[node][[1]]$name, 
                "-", filename, ".eps", sep = ""), horizontal = FALSE, 
                width = pszW, height = pszH)
        r <- min(5, round(sqrt(length(net[node][[1]]$pots[, 1]))))
        c <- min(6, 1 + round(sqrt(length(net[node][[1]]$pots[, 
            1]))))
        par(mfrow = c(r, c))
        if (verbose == "YES") {
            print(net[node][[1]]$name)
            print("Conditional:")
            print(net[node][[1]]$pots)
            print("Marginal:")
            print(net[node][[1]]$mpot)
        }
        if (is.chance(net[node][[1]])) 
            for (j in 1:length(net[node][[1]]$pots[, 1])) {
                picture <- barplot(c(net[node][[1]]$pots[j, ]), 
                  main = paste(net[node][[1]]$name, "|", net[node][[1]]$preds), 
                  names.arg = c(net[node][[1]]$values), col = "light blue", 
                  ylim = c(0, 1))
            }
        dev.off()
    }
    par(mfrow = c(1, 1))
    if (trz.probability) 
        cat("barprob: OK\n")
}
