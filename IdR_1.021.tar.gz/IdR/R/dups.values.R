dups.values <-
function (id, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("<dups.values>")
    for (i in 1:length(id)) {
        sz.dom <- length(id[i][[1]]$values)
        for (j in 1:(sz.dom - 1)) for (k in (j + 1):sz.dom) if (id[i][[1]]$values[j] == 
            id[i][[1]]$values[k]) {
            cat("Duplicate value node: ", id[i][[1]]$name, id[i][[1]]$values[j], 
                "\n")
            stop("dups.values")
            return(TRUE)
        }
    }
    return(FALSE)
}
