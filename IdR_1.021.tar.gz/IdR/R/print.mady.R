print.mady <-
function (MADY, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<print.mady")
    if (length(MADY[1, ]) > 1) {
        Names <- names(MADY[1, ])
        m <- max(nchar(Names))
        cat("\n")
        cat("..")
        for (i in 0:(m + 2)) cat(".")
        cat("", 1:length(MADY[1, ]), "\n")
        for (I in 1:length(MADY[1, ])) {
            l <- nchar(Names[I])
            if (I < 10) 
                cat(" ", I, " ", Names[I], sep = "")
            else cat(I, Names[I])
            for (i in 0:(m - l + 2)) cat(".")
            cat("")
            for (J in 1:length(MADY[1, ])) if (J < 10) 
                cat(MADY[I, J], " ", sep = "")
            else cat(MADY[I, J], "  ", sep = "")
            cat("\n")
        }
    }
    if (trz.definition) 
        cat("-print.mady>")
}
