marginal.NODE <-
function (tab0, i, EPSILON = 1e-25, laplace.correction = FALSE, 
    coma = FALSE, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# marginal.NODE: \n")
    namevars <- names(tab0)
    ll <- length(levels(factor(tab0[, i])))
    if (laplace.correction) 
        pot <- table((tab0[, i]) + 1)/(length(tab0[, i] + ll))
    else pot <- table(tab0[, i])/length(tab0[, i])
    if (ll > 1) 
        NODE <- node(Type = "CHANCE", Name = namevars[i], Values = levels(factor(tab0[, 
            i])), Preds = c(), Pots = matrix(data = pot, nrow = 1, 
            ncol = ll, byrow = TRUE, dimnames = NULL))
    if (ll == 1) 
        NODE <- node(Type = "CHANCE", Name = namevars[i], Values = c(levels(factor(tab0[, 
            i])), "ELSE"), Preds = c(), Pots = matrix(data = c(1 - 
            EPSILON, EPSILON), nrow = 1, ncol = 2, byrow = TRUE, 
            dimnames = NULL))
    if (coma) 
        cat(",\n\n")
    dump.chance(NODE)
    if (trz.probability) 
        cat("# OK\n")
    return(ll)
}
