dump.netG <-
function (net, filename = "netname", trz.primitive = FALSE) 
{
    par.version <- "version="
    par.encoding <- "encoding="
    tag.smile1 <- "<smile"
    tag.smile2 <- "</smile>\n"
    par.id <- "id="
    par.numsamples <- "numsamples="
    tag.nodes1 <- "<nodes>"
    tag.nodes2 <- "</nodes>"
    tag.cpt1 <- "<cpt "
    tag.cpt2 <- "</cpt>"
    tag.state1 <- "<state "
    tag.state2 <- "</state>"
    tag.probabilities1 <- "<probabilities>"
    tag.probabilities2 <- "</probabilities>"
    tag.parents1 <- "<parents>"
    tag.parents2 <- "</parents>"
    tag.decision1 <- "<decision "
    tag.decision2 <- "</decision>"
    tag.utility1 <- "<utility "
    tag.utility2 <- "</utility>\n"
    tag.utilities1 <- "<utilities>"
    tag.utilities2 <- "</utilities>"
    tag.extensions1 <- "<extensions>"
    tag.extensions2 <- "</extensions>"
    tag.genie1 <- "<genie "
    tag.genie2 <- "</genie>"
    par.app <- "app="
    par.name <- "name="
    par.faultnameformat <- "faultnameformat="
    tag.genie2 <- "</genie>\n"
    tag.node1 <- "<node "
    tag.node2 <- "</node>"
    tag.name1 <- "<name>"
    tag.name2 <- "</name>"
    par.color <- "color="
    tag.interior <- paste("<interior ", par.color, "\"e5f6f7\"", 
        "/>", sep = " ")
    tag.outline <- paste("<outline ", par.color, "\"000080\"", 
        "/>", sep = " ")
    par.size <- "size="
    tag.font <- paste("<font ", par.color, "\"000000\"", par.name, 
        "\"Arial\"", par.size, "\"14\"", "/>", sep = " ")
    tag.position1 <- "<position>"
    tag.position2 <- "</position>"
    NODE.CAT <- function(node) {
        cat(par.id, "\"", paste(unlist(strsplit(node$name, ".", 
            fixed = TRUE)), sep = ""), "\"", sep = "")
        cat(">\n")
        for (j in 1:length(node$values)) cat(tag.state1, par.id, 
            "\"", node$values[j], "\"", "/>\n", sep = "")
        if (length(node$preds) > 0) {
            cat(tag.parents1)
            PREDS <- c()
            for (k in 1:length(node$preds)) {
                PREDS. <- unlist(strsplit(node$preds[k], ".", 
                  fixed = TRUE))
                if (length(PREDS.) == 1) 
                  PREDS. <- paste(PREDS.[1], sep = "")
                if (length(PREDS.) == 2) 
                  PREDS. <- paste(PREDS.[1], PREDS.[2], sep = "")
                if (length(PREDS.) == 3) 
                  PREDS. <- paste(PREDS.[1], PREDS.[2], PREDS.[3], 
                    sep = "")
                if (length(PREDS.) == 4) 
                  PREDS. <- paste(PREDS.[1], PREDS.[2], PREDS.[3], 
                    PREDS.[4], sep = "")
                PREDS <- c(PREDS, PREDS.)
            }
            cat(PREDS)
            cat(tag.parents2)
            cat("\n")
        }
    }
    if (trz.primitive) 
        cat("file.netG ")
    header1 <- paste("<?xml", par.version, "\"1.0\"", par.encoding, 
        "\"ISO-8859-1\"", "?>", sep = " ")
    header2 <- paste(tag.smile1, par.version, "\"1.0\"", par.id, 
        paste("\"", filename, "\"", sep = ""), par.numsamples, 
        "\"1000\"", ">", sep = " ")
    header3 <- paste(tag.genie1, par.version, "\"1.0\"", par.app, 
        "\"GeNIe 2.0.2337.0\"", par.name, paste("\"", filename, 
            "\"", sep = ""), par.faultnameformat, "\"nodestate\"", 
        ">", sep = " ")
    cat("Save influence diagrams and bayesian networks on xdsl file: ", 
        filename, "\n")
    sink(paste(idr.output.eval(), "network-", filename, ".xdsl", 
        sep = ""))
    cat(header1)
    cat("\n")
    cat(header2)
    cat("\n")
    cat(tag.nodes1)
    cat("\n")
    nodes <- c()
    while (length(nodes) < length(net)) for (i in 1:length(net)) {
        save <- TRUE
        if (length(net[i][[1]]$preds) > 0) 
            for (j in 1:length(net[i][[1]]$preds)) if (!esta(index.id(net, 
                net[i][[1]]$preds[j]), nodes)) 
                save <- save && FALSE
        save <- (is.marginal(net[i][[1]]) || save) && !esta(index.id(net, 
            net[i][[1]]$name), nodes)
        if (save) {
            nodes <- c(nodes, index.id(net, net[i][[1]]$name))
            if (is.chance(net[i][[1]])) {
                cat(tag.cpt1)
                NODE.CAT(net[i][[1]])
                cat(tag.probabilities1)
                cat(t(Re(net[i][[1]]$pots)))
                cat(tag.probabilities2)
                cat("\n")
                cat(tag.cpt2)
                cat("\n")
            }
            if (is.decision(net[i][[1]])) {
                cat(tag.decision1)
                NODE.CAT(net[i][[1]])
                cat(tag.decision2)
                cat("\n")
            }
            if (is.utility(net[i][[1]])) {
                cat(tag.utility1)
                NODE.CAT(net[i][[1]])
                cat(tag.utilities1)
                cat(Re(net[i][[1]]$pots))
                cat(tag.utilities2)
                cat("\n")
                cat(tag.utility2)
            }
        }
    }
    cat(tag.nodes2)
    cat("\n")
    cat(tag.extensions1)
    cat("\n")
    cat(header3)
    cat("\n")
    for (i in 1:length(net)) {
        cat(tag.node1)
        cat(par.id, "\"", paste(unlist(strsplit(net[i][[1]]$name, 
            ".", fixed = TRUE)), sep = ""), "\"", ">", sep = "")
        cat("\n")
        cat(tag.name1)
        cat(paste(unlist(strsplit(net[i][[1]]$name, ".", fixed = TRUE)), 
            sep = ""))
        cat(tag.name2)
        cat("\n")
        cat(tag.interior)
        cat("\n")
        cat(tag.outline)
        cat("\n")
        cat(tag.font)
        cat("\n")
        cat(tag.position1)
        pos1 <- as.integer(runif(2, min = 0, max = 800))
        cat(pos1)
        cat(" ")
        cat(pos1 + as.integer(runif(2, min = 80, max = 100)))
        cat(tag.position2)
        cat("\n")
        cat(tag.node2)
        cat("\n")
    }
    cat(tag.genie2)
    cat(tag.extensions2)
    cat("\n")
    cat(tag.smile2)
    sink()
    if (trz.primitive) 
        cat("file.netG: OK\n")
    invisible(net)
}
