is.chance <-
function (node, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<is.chance>")
    return(node$type == "CHANCE")
}
