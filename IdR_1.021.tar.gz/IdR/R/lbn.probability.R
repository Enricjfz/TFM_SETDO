lbn.probability <-
function (x, net, EPSILON = 1e-25, laplace.correction = FALSE, 
    trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# lbn.probability: ")
    NAMES <- names(x)
    for (i in 1:dim(x)[2]) {
        node <- ann(net, NAMES[i], trz.definition = trz.probability)
        pot <- c()
        NROWS <- -1
        if (length(node$preds) == 0) {
            NROWS <- 1
            pot <- table(x[, i])/length(x[, i])
        }
        if (length(node$preds) == 1) {
            preds.levels <- ann(net, node$preds[1], trz.definition = trz.probability)$values
            NROWS <- length(preds.levels)
            for (k in 1:NROWS) {
                selection1 <- ((x[, node$preds[1]]) == (preds.levels[k]))
                k.dat <- x[selection1, c(i)]
                if (length(k.dat) == 0) {
                  pot <- c(pot, rep(1/length(node$values), length(node$values)))
                }
                else pot <- c(pot, table(k.dat)/length(k.dat))
            }
        }
        if (length(node$preds) == 2) {
            PREDS <- mdgrid(net, node, kbm2lcoded = FALSE)
            NROWS <- length(PREDS[, 1])
            for (k in 1:dim(PREDS)[1]) {
                K.DAT <- factor(x[, node$preds[1]], ordered = FALSE)
                J.DAT <- factor(PREDS[k, 1], levels = levels(K.DAT), 
                  ordered = FALSE)
                if (is.na(J.DAT)) 
                  selection1 <- FALSE
                else selection1 <- (K.DAT == J.DAT)
                k.dat <- x[selection1, ]
                if (length(k.dat) != 0) {
                  K.DAT <- factor(k.dat[, node$preds[2]], ordered = FALSE)
                  J.DAT <- factor(PREDS[k, 2], levels = levels(K.DAT), 
                    ordered = FALSE)
                  if (is.na(J.DAT)) 
                    selection2 <- FALSE
                  else selection2 <- (K.DAT == J.DAT)
                  if (sum(selection2) > 0) 
                    k.dat <- k.dat[selection2, c(i)]
                  else k.dat <- NULL
                }
                if (length(k.dat) == 0) {
                  pot <- c(pot, rep(1/length(node$values), length(node$values)))
                }
                else pot <- c(pot, table(k.dat)/length(k.dat))
            }
        }
        if (length(node$preds) == 3) {
            PREDS <- mdgrid(net, node, kbm2lcoded = FALSE)
            NROWS <- length(PREDS[, 1])
            for (k in 1:dim(PREDS)[1]) {
                K.DAT <- factor(x[, node$preds[1]], ordered = FALSE)
                J.DAT <- factor(PREDS[k, 1], levels = levels(K.DAT), 
                  ordered = FALSE)
                if (is.na(J.DAT)) 
                  selection1 <- FALSE
                else selection1 <- (K.DAT == J.DAT)
                k.dat <- x[selection1, ]
                if (length(k.dat) != 0) {
                  K.DAT <- factor(k.dat[, node$preds[2]], ordered = FALSE)
                  J.DAT <- factor(PREDS[k, 2], levels = levels(K.DAT), 
                    ordered = FALSE)
                  if (is.na(J.DAT)) 
                    selection2 <- FALSE
                  else selection2 <- (K.DAT == J.DAT)
                  if (sum(selection2) > 0) 
                    k.dat <- k.dat[selection2, ]
                  else k.dat <- NULL
                }
                if (length(k.dat) != 0) {
                  K.DAT <- factor(k.dat[, node$preds[3]], ordered = FALSE)
                  J.DAT <- factor(PREDS[k, 3], levels = levels(K.DAT), 
                    ordered = FALSE)
                  if (is.na(J.DAT)) 
                    selection3 <- FALSE
                  else selection3 <- (K.DAT == J.DAT)
                  if (sum(selection3) > 0) 
                    k.dat <- k.dat[selection3, c(i)]
                  else k.dat <- NULL
                }
                if (length(k.dat) == 0) {
                  pot <- c(pot, rep(1/length(node$values), length(node$values)))
                }
                else pot <- c(pot, table(k.dat)/length(k.dat))
            }
        }
        if (length(pot) != 1) 
            if (length(pot) != NROWS * length(node$values)) {
                sink()
                cat("node$name", node$name, "  NAMES[i]: ", NAMES[i], 
                  "  node$values: ", node$values, "  node$preds: ", 
                  node$preds, "\n")
                cat("nrow=NROWS: ", NROWS, "  ncol=length( node$values): ", 
                  length(node$values), "\n")
                print(x)
                print(pot)
                cat(sum(pot), max(pot), min(pot), "\n")
                print(matrix(data = pot, nrow = NROWS, ncol = length(node$values), 
                  byrow = TRUE, dimnames = NULL))
                stop(" *** <", node$name, ">  <", node$preds, 
                  ">  <", node$values, ">  <", length(pot), ">  <", 
                  NROWS, ">  <", length(node$values), ">")
            }
        if (length(pot) == 1) {
            node$values <- c(node$values[1], "ELSE")
            node$pots <- matrix(data = c(1 - EPSILON, EPSILON), 
                nrow = 1, ncol = 2, byrow = TRUE, dimnames = NULL)
        }
        else node$pots <- matrix(data = pot, nrow = NROWS, ncol = length(node$values), 
            byrow = TRUE, dimnames = NULL)
        net[index.id(net, node$name)][[1]] <- node(node)
    }
    if (trz.probability) 
        cat("# lbn.probability OK\n")
    return(net)
}
