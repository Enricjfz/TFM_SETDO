marnod.eval <-
function (net, name = "netname", Calc = TRUE, marg = "node", 
    simple = "NONE", trz.evaluation = FALSE) 
{
    TIME0 <- proc.time()
    net <- reset.eval(net)
    if (trz.evaluation) 
        cat("MARNOD.EVAL ")
    folder.manager()
    MADY <- mady(net)
    print.mady(MADY)
    print("Assign MARGINALS.")
    while (null.marginales(net, gr = 0, MADY)) {
        for (i in 1:length(net)) {
            if (is.chance(net[i][[1]], trz.definition = trz.evaluation)) 
                if (length(net[i][[1]]$mpot) == 0) 
                  if (is.marginal(net[i][[1]], trz.probability = trz.evaluation)) {
                    cat("Node: ", net[i][[1]]$name, " marginal node\n")
                    net[i][[1]]$mpot = net[i][[1]]$pots
                    cat("<<<<    ", as.vector(net[i][[1]]$pots), 
                      "    >>>>\n")
                  }
        }
    }
    for (C in 1:(length(net) - 1)) {
        cat("#  CONDITIONALS.", C, "  *********************************************************\n")
        while (null.marginales(net, gr = C, MADY = MADY)) {
            cat("#  CONDITIONALS.", C, "  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n")
            for (i in 1:length(net)) {
                if (is.chance(net[i][[1]], trz.definition = trz.evaluation)) 
                  if (length(net[i][[1]]$mpot) == 0) 
                    if (sum(MADY[, i]) == C) {
                      cat("Node: ", net[i][[1]]$name, "  preds: ", 
                        net[i][[1]]$preds, " conditional-C node\n")
                      if (marg == "node") 
                        net[i][[1]]$mpot <- marginalizar(net, 
                          i, Marg = marg, Simple = simple, trz.evaluation = trz.evaluation)
                      else if (marg == "network") {
                        net <- marginalizar(net, i, Marg = marg, 
                          Simple = simple, trz.evaluation = trz.evaluation)
                        MADY <- mady(net, trz.definition = trz.evaluation)
                      }
                      else stop("marg?: ", marg)
                    }
            }
        }
    }
    if (trz.evaluation) 
        cat("MARNOD.EVAL: OK\n")
    cat("#  proc.time: ", (proc.time() - TIME0)[1], "\n")
    net <- print.eval(net)
    invisible(net)
}
