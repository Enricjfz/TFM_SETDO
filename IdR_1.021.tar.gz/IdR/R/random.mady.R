random.mady <-
function (Nodes, max.gr = 0, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("#<random.mady")
    n <- Nodes
    if (max.gr == 0) 
        max.gr <- n - 1
    Mady <- matrix(data = rep(INDEP.COND_(), n * n), nrow = n, 
        ncol = n, dimnames = list(1:n, 1:n))
    for (i in 1:n) {
        desc <- sample(1:n, sample(max.gr, 1))
        Mady[i, desc] <- CONDICIONAL()
        Mady[i, i] <- INDEP.COND_()
    }
    Mady. <- Mady
    ciclo <- TRUE
    while (ciclo) {
        ciclo <- FALSE
        i <- 0
        while (i < n) {
            i <- i + 1
            j <- 0
            while (j < n) {
                if (Nodes >= 1000) 
                  cat("# random.mady   ", sum(Mady), "\n")
                j <- j + 1
                if (Mady.[i, j] == CONDICIONAL()) {
                  s <- sum(Mady.[i, ])
                  for (k in 1:n) if (Mady[j, k] == CONDICIONAL()) 
                    if (i != k) 
                      Mady.[i, k] <- CONDICIONAL()
                    else {
                      Mady[j, k] <- INDEP.COND_()
                      Mady.[j, k] <- INDEP.COND_()
                      ciclo <- TRUE
                    }
                  if (s < sum(Mady.[i, ])) {
                    i <- 0
                    j <- 0
                    break
                  }
                }
            }
        }
    }
    for (j in 1:n) while (sum(Mady[, j]) > max.gr) Mady[sample(1:n, 
        1), j] <- INDEP.COND_()
    if (trz.definition) 
        cat("#-random.mady>")
    c.c.m(Mady, msg = "random.mady")
    return(Mady)
}
