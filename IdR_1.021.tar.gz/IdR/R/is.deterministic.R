is.deterministic <-
function (node, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<is.deterministic>")
    return(node$type == "DETERMINISTIC")
}
