rc <-
function (id, node, node.U, CALC = TRUE, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("rc ")
    node.U <- inheritance.utility(id, node, node.U, Calc = CALC, 
        trz.probability = trz.evaluation)
    node.U <- conditional.expectation(id, node, node.U, Calc = CALC, 
        trz.probability = trz.evaluation)
    id[index.id(id, node.U$name)][[1]] <- node.U
    id <- id[c(-index.id(id, node$name))]
    id <- rs(id)
    if (trz.evaluation) 
        cat("rc: OK\n")
    return(id)
}
