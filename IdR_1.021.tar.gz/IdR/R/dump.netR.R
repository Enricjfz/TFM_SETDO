dump.netR <-
function (net, filename = "netname", SINK = TRUE, trz.primitive = FALSE) 
{
    dump.decision <- function(node, phase) {
        cat(node$name, " = node(Type=\"DECISION\", Name=\"", 
            node$name, sep = "")
        cat("\", Values=c(", stream.token(node$values, quote = TRUE), 
            "), Preds=c(", stream.token(node$preds, quote = TRUE))
        cat("), Pots= matrix( data = c(", phase * 1, "), dimnames = list(\"phase\",\"", 
            node$name, "\"))\n", ")", sep = "")
        return(phase + 1)
    }
    dump.utility <- function(node) {
        if (is.matrix(node$pots) == FALSE) {
            cat("The argument is not a matrix")
            stop("dump.utility")
        }
        cat(node$name, " = node(Type=\"UTILITY\", Name=\"", node$name, 
            sep = "")
        cat("\", Values=c(", stream.token(node$values, quote = TRUE), 
            "), Preds=c(", stream.token(node$preds, quote = TRUE))
        cat("),##\n Pots=matrix( data = c(\n", stream.token(as.vector(t(node$pots))), 
            "),\n", "nrow=", dim(node$pots)[1], ", ncol=", dim(node$pots)[2], 
            ", byrow=TRUE, dimnames=list( NULL, c(\"", node$name, 
            "\")))\n", ")", sep = "")
    }
    if (trz.primitive) 
        cat("#dump.netR ")
    net.type <- network.type(net)
    cat("## Save influence diagrams and bayesian networks on R file: ", 
        filename, "\n")
    if (SINK) {
        sink(paste("network-", filename, ".R", sep = ""))
        cat("###\n", sep = "")
        if (net.type == "Influence diagram") {
            cat("# Influence Diagram\n\n", sep = "")
            cat("cat( \"Influence Diagram    --  \", ", "\"", 
                filename, "\"", ", \"\\n\")", "\n", sep = "")
        }
        if (net.type == "Bayesian network") {
            cat("# Bayesian Network\n\n", sep = "")
            cat("cat( \"Bayesian Network    --  \", ", "\"", 
                filename, "\"", ", \"\\n\")", "\n", sep = "")
        }
        cat(filename, " = list( \n\n")
    }
    phase <- 1
    for (i in 1:length(net)) {
        node <- net[i][[1]]
        if (is.chance(node)) 
            dump.chance(node)
        else if (is.decision(node)) 
            phase <- dump.decision(node, phase)
        else if (is.utility(node)) 
            dump.utility(node)
        if (i < length(net)) 
            cat(",\n\n")
    }
    if (SINK) {
        cat(")\n\n")
        if (net.type == "Influence diagram") {
            cat(filename, "<- influence.diagram(", filename, 
                ")\n", sep = "")
            cat("cat( \"Influence Diagram  --  \", \"", filename, 
                "\"", ")\n", sep = "")
        }
        if (net.type == "Bayesian network") {
            cat(filename, "<- bayesian.network.(", filename, 
                ")\n", sep = "")
            cat("cat( \"Bayesian Network  --  \",", "\"", filename, 
                "\"", ")\n", sep = "")
        }
        sink()
    }
    if (trz.primitive) 
        cat("#dump.netR: OK\n")
    invisible(net)
}
