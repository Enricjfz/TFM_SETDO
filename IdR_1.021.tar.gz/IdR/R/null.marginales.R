null.marginales <-
function (net, gr = 0, MADY, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("#  null.marginales ")
    for (i in 1:length(net)) if (length(net[i][[1]]$mpot) == 
        0) 
        if (sum(MADY[, i]) == gr) 
            return(TRUE)
    if (trz.evaluation) 
        cat("null.marginales: OK\n")
    return(FALSE)
}
