influence.diagram <-
function (Nodes, Names = NULL, Probability = TRUE, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<influence.diagram")
    if (trz.definition) 
        cat("\nInfluence Diagram\nNodes: ", length(Nodes), "\n")
    if (length(Names) == 0) 
        Names <- names(Nodes)
    id <- list()
    for (i in 1:length(Nodes)) {
        node <- Nodes[i]
        names(node) <- Names[i]
        id <- c(id, node)
    }
    id <- check.rr(id)
    if (Probability) 
        id <- check.mx(id, EPSILON = 9.9999999999999995e-08, 
            CALC = TRUE, trz.probability = trz.definition)
    if (trz.definition) 
        cat("Influence Diagram: OK\n")
    if (trz.definition) 
        cat("-influence.diagram>")
    invisible(id)
}
