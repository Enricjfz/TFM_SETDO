check.marginal.node <-
function (id, node, EPSILON = 9.9999999999999995e-08, error = FALSE, 
    trz.probability = FALSE) 
{
    if (length(node$values) != length(node$pots)) {
        cat("\nNode: ", node$name, "\n")
        cat("marg.node not fit.sz", "\n")
        error <- TRUE | error
    }
    else {
        if (sum(node$pots) - 1 > EPSILON) {
            if (trz.probability) {
                cat("\nNode: ", node$name, "\n")
                cat("marg.node not sum.1.0", "\n")
            }
            error <- TRUE | error
        }
    }
    return(error)
}
