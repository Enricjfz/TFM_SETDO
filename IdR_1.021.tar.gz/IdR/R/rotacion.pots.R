rotacion.pots <-
function (id, node, Preds, ELTOS = 20, trz.probability = FALSE) 
{
    if (trz.probability) {
        cat("rotacion.pots \n")
        print(node$preds)
        print(node$pots[1:min(length(node$pots[, 1]), ELTOS), 
            ])
    }
    if (length(node$preds) <= 1) {
        if (node$preds[1] == Preds[1]) {
            if (trz.probability) 
                cat("rotacion.pots: OK-1\n")
            return(node)
        }
        else {
            cat("Preds", Preds, "\n")
            stop("predecesores incompatibles.1")
        }
    }
    ROT <- FALSE
    for (i in length(Preds):1) {
        if (Preds[i] != node$preds[length(node$preds) + i - length(Preds)]) {
            ROT <- TRUE
            break
        }
    }
    if (!ROT) {
        if (trz.probability) 
            cat("rotacion.pots: OK-2\n")
        return(node)
    }
    old.preds <- node$preds
    for (i in 1:length(Preds)) {
        if (!esta(Preds[i], old.preds)) {
            cat("old.preds", old.preds, "\n")
            cat("Preds", Preds, "\n")
            stop("predecesores incompatibles.2")
        }
    }
    exc.preds <- old.preds
    for (i in 1:length(Preds)) {
        exc.preds = remove.name(exc.preds, Preds[i])
    }
    new.preds <- c(exc.preds, Preds)
    perm <- 1:length(old.preds)
    for (i in 1:length(old.preds)) if (new.preds[i] != old.preds[i]) 
        perm[i] <- which(old.preds == new.preds[i])
    old.index <- matrix.index(id, node, trz.probability = trz.probability)
    if (is.chance(node)) {
        perm <- c(perm, length(perm) + 1)
        new.index <- aperm(old.index, 1 + length(perm) - rev(perm))
        node$pots <- t(node$pots)
        node$pots <- node$pots[as.vector(new.index)]
        node$pots <- t(node$pots)
        dnames <- list(c(1:(length(node$pots)/length(node$values))))
        dnames <- c(dnames, list(c(1:(length(node$values)))))
        node$pots <- matrix(data = node$pots, ncol = length(node$values), 
            byrow = TRUE, dimnames = dnames)
    }
    if (is.utility(node)) {
        new.index <- aperm(old.index, 1 + length(perm) - rev(perm))
        node$pots <- node$pots[as.vector(new.index)]
        dnames <- list(c(1:length(node$pots)))
        dnames <- c(dnames, list(c("utility")))
        node$pots <- matrix(data = node$pots, ncol = 1, byrow = TRUE, 
            dimnames = dnames)
    }
    node$preds <- new.preds
    if (trz.probability) {
        print(node$preds)
        print(node$pots[1:min(length(node$pots[, 1]), ELTOS), 
            ])
        cat("rotacion.pots: OK-3\n")
    }
    return(node)
}
