reset.eval <-
function (net, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("#  reset.eval ")
    for (i in 1:length(net)) {
        if (is.chance(net[i][[1]])) 
            net[i][[1]]$mpot = NULL
    }
    if (trz.evaluation) 
        cat("reset.eval: OK\n")
    return(net)
}
