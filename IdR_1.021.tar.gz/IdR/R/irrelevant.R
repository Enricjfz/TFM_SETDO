irrelevant <-
function (node, v, b, trz.definition = FALSE) 
{
    irr <- TRUE
    for (q in 1:b) {
        IRR. <- mean(abs(as.vector(t(node$pots[(1 + v * (q - 
            1)):(v * q), ])) - rep(node$pots[(v * q), ], v)))
        print(node$pots)
        print(IRR.)
        irr <- irr & (IRR. <= 1e-10/2)
        if (!irr) 
            break
    }
    return(irr)
}
