remove.name <-
function (V, N, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("<remove.name ")
    if (length(N) == 0) 
        return(V)
    if (length(V) == 0) {
        return(V)
    }
    Vr <- c()
    for (i in 1:length(V)) {
        if (V[i] != N[1]) {
            Vr <- c(Vr, V[i])
        }
    }
    if (trz.primitive) 
        cat("remove.name: OK>\n")
    return(Vr)
}
