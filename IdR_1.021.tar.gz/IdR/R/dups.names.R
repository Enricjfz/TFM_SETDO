dups.names <-
function (id, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("<dups.names>")
    for (i in 1:(length(id) - 1)) {
        for (j in (i + 1):length(id)) {
            if (id[i][[1]]$name == id[j][[1]]$name) {
                cat("Duplicate name node: ", id[i][[1]]$name, 
                  i, j, "\n")
                stop("dups.names")
                return(TRUE)
            }
        }
    }
    return(FALSE)
}
