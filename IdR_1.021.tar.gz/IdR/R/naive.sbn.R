naive.sbn <-
function (bn, tab0, class.name, ssz, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("naive.sbn: ")
    namevars <- names(tab0)
    class.node <- ann(bn, class.name, STOP = FALSE)
    if (length(class.node) == 0) 
        stop("naive bayes has constant class node. ", class.name, 
            "   ", class.node$values)
    else cat("rbn ", class.node$name, "   ", class.node$values, 
        "   ssz ---", ssz, "\n")
    optLABELS <- names(table(tab0$yfit))
    bn.simu <- NULL
    feature.node <- NULL
    bn.simu <- data.frame(sample(class.node$values, size = ssz, 
        replace = TRUE, prob = as.vector(class.node$pots)))
    for (i.name in length(namevars):1) if (namevars[i.name] != 
        class.name) {
        feature.node <- ann(bn, namevars[i.name], STOP = FALSE)
        if (length(feature.node) == 0) {
            bn.simu <- cbind(rep(tab0[1, i.name], ssz), bn.simu)
        }
        else {
            i.sample <- c()
            for (j in 1:ssz) {
                k <- which(optLABELS == bn.simu[j, length(bn.simu[1, 
                  ])])
                i.sample <- c(i.sample, sample(feature.node$values, 
                  size = 1, replace = TRUE, prob = feature.node$pots[k, 
                    ]))
            }
            if (length(bn.simu) == 0) 
                bn.simu <- data.frame(i.sample)
            else bn.simu <- cbind(i.sample, bn.simu)
        }
    }
    if (trz.probability) 
        cat("OK\n")
    return(bn.simu)
}
