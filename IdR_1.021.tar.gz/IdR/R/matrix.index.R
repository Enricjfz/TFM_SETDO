matrix.index <-
function (id, node, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("matrix.index \n")
    a <- NULL
    if (!is.decision(node)) {
        if (is.matrix(node$pots)) {
            DATA <- 1:length(node$pots)
            if (is.chance(node)) {
                DIM <- rev(c(Dim(id, node$preds), length(node$values)))
                DNAMES <- rev(c(node$preds, node$name))
                dnames <- list(ann(id, DNAMES[1])$values)
                for (k in 2:length(DIM)) {
                  dnames <- c(dnames, list(ann(id, DNAMES[k])$values))
                }
                if (trz.probability) {
                  print(DIM)
                  print(DNAMES)
                  print(dnames)
                }
                a <- array(data = DATA, dim = DIM, dimnames = (dnames))
            }
            if (is.utility(node)) {
                DIM <- rev(Dim(id, node$preds))
                DNAMES <- rev(c(node$preds))
                dnames <- list(ann(id, DNAMES[1])$values)
                for (k in 2:length(DIM)) {
                  dnames <- c(dnames, list(ann(id, DNAMES[k])$values))
                }
                if (trz.probability) {
                  print(DIM)
                  print(DNAMES)
                  print(dnames)
                }
                a <- array(data = DATA, dim = DIM, dimnames = (dnames))
            }
        }
        else stop("non matrix node$pots ( a == NULL)")
    }
    else stop("decision node ( a == NULL)")
    if (trz.probability) 
        cat("matrix.index: OK\n")
    return(a)
}
