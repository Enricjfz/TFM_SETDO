dstobds <-
function (dataset) 
{
    ds <- read.table(dataset, header = TRUE)
    print(summary(ds))
    print(head(ds))
    names.ds <- names(ds)
    names.bds <- c()
    sz.vars <- c()
    for (n in 1:length(names.ds)) {
        values <- sort(unique(ds[, n]))
        sz.vars <- c(sz.vars, length(values))
        for (v in values) {
            m <- paste(names.ds[n], toString(v), sep = "")
            names.bds <- c(names.bds, m)
        }
    }
    rows <- dim(ds)[1]
    cols <- dim(ds)[2]
    bds <- rbind(rep(0, length(names.bds)))
    names(bds) <- names.bds
    print(names(bds))
    for (j in 1:cols) {
        values <- sort(unique(ds[, j]))
        if (j == 1) 
            bds[1, which(values == ds[1, j])] <- 1
        else bds[1, sum(sz.vars[1:(j - 1)]) + which(values == 
            ds[1, j])] <- 1
    }
    for (i in 2:rows) {
        bds <- rbind(bds, rep(0, length(names.bds)))
        for (j in 1:cols) {
            values <- sort(unique(ds[, j]))
            if (j == 1) 
                bds[i, which(values == ds[i, j])] <- 1
            else bds[i, sum(sz.vars[1:(j - 1)]) + which(values == 
                ds[i, j])] <- 1
        }
    }
    names(bds) <- names.bds
    print(head(bds))
    write.table(bds, file = paste("dataset", "-bds.txt", sep = ""), 
        row.names = FALSE)
    return(bds)
}
