guided.remnod.eval <-
function (id, nodelist, CALC = TRUE, ELTOS = 40, DUMP = FALSE, 
    trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("GUIDED.REMNOD.EVAL ")
    folder.manager()
    if (trz.evaluation) 
        cat("GUIDED.REMNOD.EVAL: OK\n")
    return(id)
}
