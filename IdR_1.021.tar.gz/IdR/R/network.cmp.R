network.cmp <-
function (id0, id, fstop = TRUE, trz.definition = FALSE) 
{
    equal.network <- TRUE
    if (trz.definition) 
        cat("<network.cmp-")
    if (length(id0) != length(id)) {
        cat("Length \n")
        equal.network <- FALSE
        if (fstop) 
            return(FALSE)
    }
    if (trz.definition) 
        cat("[length]")
    if (sum(mady(network.sort(id0, trz.definition = trz.definition), 
        trz.definition = trz.definition) != mady(network.sort(id, 
        trz.definition = trz.definition), trz.definition = trz.definition))) {
        cat("MADY \n")
        equal.network <- FALSE
        if (fstop) 
            return(FALSE)
    }
    if (trz.definition) 
        cat("[mady]")
    if (sum(sort(names(id0)) != sort(names(id))) > 0) {
        cat("Schema \n")
        equal.network <- FALSE
        if (fstop) 
            return(FALSE)
    }
    if (trz.definition) 
        cat("[sort]")
    if (id.size.real(id0) != id.size.real(id)) {
        cat("id.size.real \n")
        equal.network <- FALSE
        if (fstop) 
            return(FALSE)
    }
    if (trz.definition) 
        cat("[id.size.real]")
    for (i in 1:length(id)) {
        if (id0[i][[1]]$type != id[i][[1]]$type) {
            cat("type \n")
            equal.network <- FALSE
            if (fstop) 
                return(FALSE)
        }
        if (id0[i][[1]]$name != id[i][[1]]$name) {
            cat("name \n")
            equal.network <- FALSE
            if (fstop) 
                return(FALSE)
        }
        for (v in 1:length(id0[i][[1]]$values)) if (id0[i][[1]]$values[v] != 
            id[i][[1]]$values[v]) {
            cat("values \n")
            equal.network <- FALSE
            if (fstop) 
                return(FALSE)
        }
        if (length(id0[i][[1]]$preds) != length(id[i][[1]]$preds)) {
            cat("preds. ", id0[i][[1]]$name, id[i][[1]]$name, 
                "\n")
            equal.network <- FALSE
            if (fstop) 
                return(FALSE)
        }
        else if (length(id0[i][[1]]$preds) != 0) 
            if (id0[i][[1]]$preds != id[i][[1]]$preds) {
                cat("preds \n")
                equal.network <- FALSE
                if (fstop) 
                  return(FALSE)
            }
        for (p in 1:length(id0[i][[1]]$pots[, 1])) for (v in 1:length(id0[i][[1]]$values)) {
            V0 <- id0[i][[1]]$pots[p, v]
            V <- id[i][[1]]$pots[p, v]
            if (Re(V0) != Re(V)) {
                cat("pots \n")
                cat(id0[i][[1]]$name, id[i][[1]]$name, "\n")
                print(V0)
                print(V)
                equal.network <- FALSE
                if (fstop) 
                  return(FALSE)
            }
        }
    }
    if (trz.definition) 
        cat("-network.cmp>")
    return(equal.network)
}
