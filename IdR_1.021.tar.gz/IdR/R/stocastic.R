stocastic <-
function (pots) 
{
    rc <- dim(pots)
    for (i in 1:rc[1]) for (j in 1:rc[2]) {
        if (pots[i, j] < 0) {
            if (abs(pots[i, j]) < 9.9999999999999998e-13) 
                pots[i, j] <- 0
            else pots[i, j] <- 0
        }
        if (pots[i, j] > 0) {
            if (abs(pots[i, j]) < 9.9999999999999998e-13) 
                pots[i, j] <- 0
        }
    }
    for (i in 1:rc[1]) pots[i, ] <- pots[i, ]/sum(pots[i, ])
    return(pots)
}
