fd <-
function (id, preds.index, preds.weights, preds.values, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("fd: ")
    if (length(preds.values) == 0) 
        return(1)
    indx.atts <- Indx(id, preds.index, preds.values)
    offset <- sum((indx.atts - 1) * preds.weights) + 1
    if (trz.probability) 
        cat("OK\n")
    return(offset)
}
