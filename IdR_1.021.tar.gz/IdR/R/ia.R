ia <-
function (id, node.i, node.j, CALC = TRUE, trz.evaluation = FALSE) 
{
    if (trz.evaluation) {
        cat("ia ", node.i$name, " ---> ", node.j$name, "\n")
    }
    if (!is.chance(node.i) || !is.chance(node.j)) {
        stop("Non chance nodes  ", node.i$name, "   ", node.j$name)
    }
    if (esta(node.j$name, node.i$preds)) {
        return(ia(id, node.j, node.i, trz.evaluation))
    }
    if (!esta(node.i$name, node.j$preds)) {
        return(id)
        stop("it does not exist an edge between i,j nodes")
    }
    if (trz.evaluation) {
        cat("ia 1i ", node.i$preds, "\n")
        cat("ia 1j ", node.j$preds, "\n")
    }
    node.k <- node(node.j)
    node.l <- node(node.i)
    added.i <- c()
    added.j <- c()
    node.i.preds <- node.i$preds
    if (length(node.j$preds) > 0) {
        added.i <- add.names(node.i$preds, node.j$preds)
        node.i$preds <- c(added.i, node.i$preds)
        node.i$preds <- remove.name(node.i$preds, node.i$name)
    }
    if (length(node.i.preds) > 0) {
        added.j <- add.names(node.j$preds, node.i.preds)
        node.j$preds <- c(added.j, node.j$preds)
        node.j$preds <- remove.name(node.j$preds, node.j$name)
    }
    node.i.preds <- node.i$preds
    node.j.preds <- node.j$preds
    node.i$preds <- c(add.names(node.i$preds, node.j$name), node.i$preds)
    node.j$preds <- remove.name(node.j$preds, node.i$name)
    xi <- index.id(id, node.i$name)
    id[xi][[1]] <- node(node.i)
    xj <- index.id(id, node.j$name)
    id[xj][[1]] <- node(node.j)
    if (c.c(id, c(0, xi, xj), msg = "ia")) {
        if (trz.evaluation) 
            cat("ia: OK.1 rollback\n")
        id[index.id(id, node.i$name)][[1]] <- node(node.l)
        id[index.id(id, node.j$name)][[1]] <- node(node.k)
        return(id)
    }
    node.j$preds <- node.j.preds
    node.i$preds <- node.i.preds
    id[index.id(id, node.i$name)][[1]] <- node(node.i)
    id[index.id(id, node.j$name)][[1]] <- node(node.j)
    node.j$pots <- inheritance.probability(id, node.j, node.k, 
        Calc = CALC, trz.probability = trz.evaluation)
    node.i$pots <- inheritance.probability(id, node.i, node.l, 
        Calc = CALC, trz.probability = trz.evaluation)
    node.k <- node(node.j)
    node.l <- node(node.i)
    node.j$pots <- bayes.j(id, node.l, node.k, Calc = CALC, trz.evaluation = trz.evaluation)
    node.j$maxszpot = max(node.j$maxszpot, length(node.j$pots[, 
        1]))
    node.i$pots <- bayes.i(id, node.l, node.k, Calc = CALC, trz.evaluation = trz.evaluation)
    node.i$maxszpot = max(node.i$maxszpot, length(node.i$pots[, 
        1]))
    node.i$preds <- c(node.i$preds, add.names(node.i$preds, node.j$name))
    node.j$preds <- remove.name(node.j$preds, node.i$name)
    if (trz.evaluation) {
        cat("ia 2i ", node.i$preds, "\n")
        cat("ia 2j ", node.j$preds, "\n")
    }
    id[index.id(id, node.i$name)][[1]] <- node(node.i)
    id[index.id(id, node.j$name)][[1]] <- node(node.j)
    if (trz.evaluation) {
        id <- check.rr(id, trz.definition = trz.evaluation)
        id <- check.mx(id, CALC = CALC, trz.probability = trz.evaluation)
    }
    check.mx(id, index.id(id, node.i$name), CALC = CALC, trz.probability = trz.evaluation)
    check.mx(id, index.id(id, node.j$name), CALC = CALC, trz.probability = trz.evaluation)
    if (trz.evaluation) 
        cat("ia: OK.2\n")
    return(id)
}
