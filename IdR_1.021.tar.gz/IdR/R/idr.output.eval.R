idr.output.eval <-
function (bar = "Yes") 
{
    if (bar == "Yes") 
        return("IdR-OutPutEval/")
    else return("IdR-OutPutEval")
}
