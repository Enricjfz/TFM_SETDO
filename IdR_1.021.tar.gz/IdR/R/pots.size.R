pots.size <-
function (id, node, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("<pots.size")
    if (length(node$preds) == 0) {
        if (trz.probability) 
            cat("-pots.size>\n")
        return(1)
    }
    size <- 1
    for (j in 1:length(node$preds)) {
        size <- size * length(ann(id, node$preds[j], trz.probability)$values)
    }
    if (size < 2) {
        cat("\nNode:  ", node$name, "\n")
        cat("Preds: ", node$preds, "\n")
        stop("Error2. pots.size")
    }
    if (trz.probability) 
        cat("-pots.size>\n")
    return(size)
}
