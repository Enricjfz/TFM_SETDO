inheritance.probability <-
function (id, node, node.P, Calc = TRUE, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("inheritance.probability ", node$name, "\n")
    if (Calc) {
        nv <- length(node.P$values)
        sz0 <- length(node.P$pots[, 1])
        sz1 <- pots.size(id, node)
        if (sz0 > sz1) {
            cat("name: ", node$name, "  preds: ", node$preds, 
                "  node$values: ", nv, "\n")
            cat("old.size: ", sz0, "  new.size: ", sz1, "\n")
            stop("sz0 > sz1")
        }
        if (sz0 == sz1) {
            if (trz.probability) 
                cat("sz0 == sz1: ", sz0, node$preds, "\n", node.P$preds, 
                  "\n")
            if (trz.probability) 
                cat("inheritance.probability: OK-1\n")
            return(node.P$pots)
        }
        dat <- data.frame(V = rep(node.P$pots[, 1], sz1/sz0))
        for (i in 2:nv) {
            name <- node$values[i]
            dat <- data.frame(dat, V = rep(node.P$pots[, i], 
                sz1/sz0))
        }
        node$pots <- as.matrix(dat)
    }
    if (trz.probability) 
        cat("inheritance.probability: OK-2\n")
    return(node$pots)
}
