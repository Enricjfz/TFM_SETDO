inheritance.utility <-
function (id, node, node.U, Calc = TRUE, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("inheritance.utility ")
    node.U$preds <- c(add.names(node.U$preds, node$preds), node.U$preds)
    if (Calc) {
        sz0 <- length(node.U$pots[, 1])
        sz1 <- pots.size(id, node.U)
        if (sz0 == sz1) {
            if (trz.probability) 
                cat("inheritance.utility: OK-1\n")
            return(node.U)
        }
        if (sz0 > sz1) {
            cat("name: ", node.U$name, "  preds: ", node.U$preds, 
                "  old.size: ", sz0, "  new.size: ", sz1, "\n")
            stop("sz0 (old size) > sz1 (new size) in inheritance?")
        }
        node.U$pots <- matrix(data = rep(as.vector(node.U$pots[, 
            1]), sz1/sz0), ncol = 1, byrow = TRUE, dimnames = list(NULL, 
            c("utility")))
    }
    if (trz.probability) 
        cat("inheritance.utility: OK-2\n")
    return(node.U)
}
