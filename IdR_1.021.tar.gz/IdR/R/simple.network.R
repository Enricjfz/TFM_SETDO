simple.network <-
function (net, node = 0, simple = "IRR", SIMPLE.GR = 5, trz.definition = FALSE) 
{
    simple.pots <- function(net, node.i, j.name, vals, blocks) {
        c.c(net, 0, "simple.pots1")
        if (length(node.i$preds) == 1) {
            node.i$preds = c()
        }
        else {
            node.i$preds <- node.i$preds[1:(length(node.i$preds) - 
                1)]
        }
        c.c(net, 0, "simple.pots2")
        node.i$pots <- matrix(data = t(node.i$pots[seq(1, vals * 
            blocks, vals), ]), nrow = blocks, ncol = length(node.i$values), 
            byrow = TRUE, dimnames = NULL)
        net[index.id(net, node.i$name)][[1]] <- node(node.i)
        return(net)
    }
    simple.node <- function(net, node.i = 0, simple = "IRR", 
        trz.definition = FALSE) {
        if (trz.definition) 
            cat("<simple.node")
        if (simple == "RR") {
            RRvector <- influences.node(net, node.i)
            j.name <- node.i$preds[which.min(RRvector)]
            cat("simple: \n")
            print(node.i$preds)
            print(RRvector)
            cat("simple ", j.name, " ---> ", node.i$name, "\n")
            vals <- length(ann(net, j.name)$values)
            blocks <- length(node.i$pots[, 1])/vals
            node.i <- rotacion.pots(net, node.i, c(j.name))
            if (length(node.i$preds) > SIMPLE.GR) {
                net <- simple.pots(net, node.i, j.name, vals, 
                  blocks)
            }
        }
        else {
            PREDS <- (node.i$preds)
            for (j.name in PREDS) if (esta(j.name, node.i$preds)) {
                vals <- length(ann(net, j.name)$values)
                blocks <- length(node.i$pots[, 1])/vals
                node.i <- rotacion.pots(net, node.i, c(j.name))
                if (irrelevant(node.i, vals, blocks)) {
                  net <- simple.pots(net, node.i, j.name, vals, 
                    blocks)
                }
            }
        }
        if (trz.definition) 
            cat("-simple.node>")
        return(net)
    }
    if (trz.definition) {
        cat("<simple.network-\n")
        summary.network(net)
    }
    if (simple != "NONE") {
        if (node == 0) 
            for (i in 1:length(net)) {
                node.i <- net[i][[1]]
                if (!is.marginal(node.i)) {
                  net <- simple.node(net, node.i, simple, trz.definition)
                }
            }
        else {
            node.i <- net[node][[1]]
            if (!is.marginal(node.i)) {
                net <- simple.node(net, node.i, simple, trz.definition)
            }
        }
        if (trz.definition) {
            summary.network(net)
            cat("-simple.network>")
        }
    }
    return(net)
}
