is.discrete <-
function (node, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<is.discrete>")
    return(node$type %in% nodeTYPEd())
}
