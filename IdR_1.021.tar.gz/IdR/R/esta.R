esta <-
function (E, V, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("<esta")
    if (length(E) == 0) {
        if (trz.primitive) 
            cat("-1>")
        return(TRUE)
    }
    if (length(V) == 0) {
        if (trz.primitive) 
            cat("-2>")
        return(FALSE)
    }
    ESTA <- TRUE
    for (k in 1:length(E)) {
        ESTA <- FALSE
        for (i in 1:length(V)) if (E[k] == V[i]) {
            ESTA <- TRUE
            break
        }
        if (!ESTA) 
            return(FALSE)
    }
    if (trz.primitive) 
        cat("-3>")
    return(ESTA)
}
