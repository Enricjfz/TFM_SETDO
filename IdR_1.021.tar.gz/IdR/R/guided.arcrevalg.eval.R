guided.arcrevalg.eval <-
function (id, nodelist, CALC = TRUE, ELTOS = 40, DUMP = FALSE, 
    trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("GUIDED.ARCREVALG.EVAL ")
    folder.manager()
    print(nodelist)
    id <- am(id)
    node.U <- utility.node(id)
    if (CALC) {
        cat("node.U$preds: ", node.U$preds, "\n")
        print(node.U$pots[1:min(length(node.U$pots), ELTOS)])
    }
    i <- 0
    while (i != length(nodelist)) {
        node <- NULL
        i <- i + 1
        node <- ann(id, nodelist[i], STOP = FALSE)
        if (node == NULL) {
            i <- i + 1
            node <- ann(id, nodelist[i], STOP = FALSE)
        }
        if (is.chance(node)) {
            cat("\n[remove chance node: ", node$name, "]\n")
            if (DUMP) 
                dump.tpc(id, CALC, id[i][[1]], node.U, NumClusters, 
                  trz.evaluation)
            id <- rc(id, node, node.U, CALC = CALC, trz.evaluation = trz.evaluation)
        }
        else if (is.decision(node)) {
            cat("\n[remove decision node: ", node$name, "]\n")
            if (DUMP) 
                dump.tdu(id, CALC, id[i][[1]], node.U)
            id <- rd(id, node, node.U, CALC = CALC, trz.evaluation = trz.evaluation)
        }
        else if (is.utility(node)) {
            node.i <- ann(id, nodelist[i + 1])
            node.j <- ann(id, nodelist[i + 2])
            cat("\n[reversal arc from: ", node.i$name, "]")
            cat("\n[to: ", node.j$name, "OK]\n")
            id <- ia(id, node.i, node.j, CALC = CALC, trz.evaluation = trz.evaluation)
            i <- i + 2
            if (i == length(nodelist)) 
                break
        }
        node.U <- utility.node(id)
        cat("node.U: ", node.U$name, "   ")
        cat("node.U$preds: ", node.U$preds, "\n")
        cat("id.size.real: ", id.size.real(id), "   ")
        cat("id.size.nominal:", id.size.nominal(id), "\n")
        if (CALC) {
            cat("node.U$preds: ", node.U$preds, "\n")
            print(node.U$pots[1:min(length(node.U$pots), ELTOS)])
        }
    }
    if (trz.evaluation) 
        cat("GUIDED.ARCREVALG.EVAL: OK\n")
    return(id)
}
