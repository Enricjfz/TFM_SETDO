random.model <-
function (FileName = "randomgraphicalmodel.R", Seed = 1208, NumNodes = 10, 
    Max.Gr = 0, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<random.model-")
    if (!file.exists(FileName)) {
        set.seed(Seed, kind = "default")
        rpgm <- random.network(Nodes = NumNodes, Domains = rbinom(NumNodes, 
            10, 0.050000000000000003) + 2, max.gr = Max.Gr)
        dump.netR(rpgm, filename = FileName)
        dump.netG(rpgm, filename = FileName)
    }
    else {
        source(FileName)
        summary.network(rpgm, name = FileName)
        if (trz.definition) 
            cat("-random.model>")
        return(rpgm)
    }
}
