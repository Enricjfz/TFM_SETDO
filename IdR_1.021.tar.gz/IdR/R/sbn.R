sbn <-
function (bn.file, tab0, ssz = N, nettype = "xbayes", class.name = NULL, 
    trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# sbn: ")
    namevars <- names(tab0)
    source(bn.file)
    if (nettype == "mbayes") {
        bn.simu <- marginal.sbn(bn, tab0, ssz, trz.probability = trz.probability)
    }
    if (nettype == "nbayes") {
        bn.simu <- naive.sbn(bn, tab0, class.name, ssz, trz.probability = trz.probability)
    }
    if (nettype == "xbayes") {
        max.gr <- max(mady(bn)[, 1:length(bn)])
        if (max.gr <= 5) 
            bn.simu <- x5.sbn(bn, tab0, ssz, trz.probability = trz.probability)
        else stop("max.gr > 5.")
    }
    names(bn.simu) <- namevars
    if (trz.probability) 
        cat("# sbn OK\n")
    return(bn.simu)
}
