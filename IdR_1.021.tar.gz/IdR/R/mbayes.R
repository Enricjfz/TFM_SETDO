mbayes <-
function (tab0, laplace.correction = FALSE, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# mbayes: \n")
    t0 <- proc.time()
    namevars <- names(tab0)
    for (i in 1:length(namevars)) {
        cat("#n#  Node ", namevars[i], "  Values ", levels(factor(tab0[, 
            i])), "  length( Values) ", length(levels(factor(tab0[, 
            i]))), "\n")
        marginal.NODE(tab0, i, 1e-25, laplace.correction, trz.probability)
        if (i < length(namevars)) 
            cat(",\n\n")
    }
    if (trz.probability) 
        cat("# OK\n")
    cat("# mbayes in ", (proc.time() - t0)[1], " seconds.\n")
    return()
}
