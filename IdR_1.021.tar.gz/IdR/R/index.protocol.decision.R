index.protocol.decision <-
function (id, DimParam = -1, PARAMS = NULL, trz.tables = FALSE) 
{
    DECISIONS <- decisions(id, names(id), trz.definition = trz.tables)
    sink(paste(idr.output.eval(), stream.token(DECISIONS, tksep = "-"), 
        ".ipd", sep = ""))
    cat("; ipd -> itd -> tdu\n")
    cat("; indice de protocolo de decisiones en orden cronologico\n")
    cat("; instancia de tabla de decision\n")
    cat("; tabla de decision-utilidad\n")
    cat("DimParam: ", -1, " ;\n")
    cat("PARAMS: ", PARAMS, ";\n")
    for (i in 1:length(DECISIONS)) {
        cat(DECISIONS[i], " ;\n")
    }
    sink()
    return(DECISIONS)
}
