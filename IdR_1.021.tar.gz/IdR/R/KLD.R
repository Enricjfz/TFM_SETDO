KLD <-
function (data, data.p, net, EPSILON = 1e-10, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# KLD: ")
    .mady <- mady(net, trz.definition = trz.probability)
    max.gr <- max(apply(.mady, 2, sum))
    if (max.gr <= 3) 
        simu <- x3.sbn(bn = net, tab0 = data, ssz = dim(data)[1] * 
            3, trz.probability = trz.probability)
    else stop("MDL <- max.gr > 3")
    simu.q <- raw.joint.prob(tab0 = rbind(simu, data.p[, 1:(dim(data)[2])]), 
        trz.probability = trz.probability)
    key.q <- simu.q$key
    for (i in 1:dim(data.p)[1]) if (!(data.p[i, ]$key %in% key.q)) 
        simu.q <- rbind(simu.q, data.frame((data.p[i, 1:(dim(data)[2])]), 
            fr = c(EPSILON), key = data.p[i, ]$key))
    key.p <- data.p$key
    for (i in 1:dim(simu.q)[1]) if (!(simu.q[i, ]$key %in% key.p)) 
        data.p <- rbind(data.p, data.frame((simu.q[i, 1:(dim(data)[2])]), 
            fr = c(EPSILON), key = simu.q[i, ]$key))
    data.p <- data.p[order(data.p$key), ]
    simu.q <- simu.q[order(simu.q$key), ]
    kld <- 0
    for (i in 1:dim(simu.q)[1]) {
        kld <- kld + (simu.q[i, ]$fr * log2(simu.q[i, ]$fr/data.p[i, 
            ]$fr) + data.p[i, ]$fr * log2(data.p[i, ]$fr/simu.q[i, 
            ]$fr))/2
    }
    if (trz.probability) 
        cat("# KLD OK\n")
    return(kld)
}
