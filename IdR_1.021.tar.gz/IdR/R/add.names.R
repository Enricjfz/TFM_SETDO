add.names <-
function (V, W, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("<add.names ")
    Va <- c()
    for (i in 1:length(W)) if (!esta(W[i], V)) 
        Va <- c(Va, W[i])
    if (trz.primitive) 
        cat("add.names: OK>\n")
    return(Va)
}
