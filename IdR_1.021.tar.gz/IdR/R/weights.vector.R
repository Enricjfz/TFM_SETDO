weights.vector <-
function (id, preds, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("weigths.vector: ")
    if (length(preds) < 1) 
        stop("NULL preds")
    weight <- c(1)
    if (length(preds) == 1) 
        return(weight)
    for (i in (length(preds) - 1):1) {
        lv = length(ann(id, preds[i + 1], trz.definition = trz.probability)$values)
        wi <- weight[1]
        weight <- c(wi * lv, weight)
    }
    if (trz.probability) 
        cat("OK\n")
    return(weight)
}
