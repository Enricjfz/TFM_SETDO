Dim <-
function (net, Preds, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("Dim ")
    if (length(Preds) == 0) 
        return(NULL)
    D <- c()
    for (i in 1:length(Preds)) {
        D <- c(D, length(ann(net, Preds[i])$values))
    }
    if (trz.probability) 
        cat("Dim: OK\n")
    return(D)
}
