am <-
function (id, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("am ")
    MADY <- mady(id)
    for (i in 1:length(id)) {
        if (is.decision(id[i][[1]])) 
            for (j in 1:length(id)) {
                if (is.decision(id[j][[1]])) {
                  all.preds <- sp(id, id[j][[1]], MADY)
                  if (esta(id[i][[1]]$name, all.preds)) {
                    Preds.i <- c(id[i][[1]]$preds, id[i][[1]]$name)
                    for (k in 1:length(Preds.i)) {
                      if (!esta(Preds.i[k], id[j][[1]]$preds)) 
                        id[j][[1]]$preds <- c(id[j][[1]]$preds, 
                          Preds.i[k])
                    }
                  }
                }
                MADY <- mady(id)
            }
    }
    c.c(id, 0, msg = "am")
    if (trz.evaluation) 
        cat("am: OK\n")
    return(id)
}
