c.c.m <-
function (MADY, node = 0, msg = "ia", trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<c.c.m")
    n <- dim(MADY)[1]
    if (node[1] == 0) 
        nodeset <- 1:n
    else nodeset <- node
    for (i in nodeset) if (!(sum(MADY[, i]) == 0)) {
        if (!(sum(MADY[i, ]) == 0)) {
            SUCCS <- MADY[i, ]
            for (k in 1:n) {
                for (j in 1:n) if (SUCCS[j] == CONDICIONAL()) 
                  SUCCS <- (SUCCS + MADY[j, ])
                SUCCS[SUCCS > INDEP.COND_()] <- CONDICIONAL()
                if (SUCCS[i] == CONDICIONAL()) {
                  if (msg != "ia") {
                    sink()
                    print(MADY)
                    cat("\n  C.C: msg --- ", msg, "  i:", i, 
                      "\n")
                    cat("\n  C.C: SUCCS --- ", SUCCS, "\n")
                    cat("cicle: node ", i, "  preds: ", MADY[, 
                      i], "\n")
                    stop("-c.c.m!!")
                  }
                  else return(TRUE)
                }
            }
        }
    }
    if (trz.definition) 
        cat("-c.c.m>")
    return(FALSE)
}
