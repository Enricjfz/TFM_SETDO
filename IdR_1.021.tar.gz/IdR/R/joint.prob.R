joint.prob <-
function (tab0, labels, correction = 0, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# joint.prob: ")
    if (length(tab0$LBL) == 0) 
        tab0 <- label.joint.prob(tab0, labels)
    if (correction > 0) {
        CTABLE <- table(tab0$LBL) - 1
        CTABLE <- CTABLE/(length(tab0[, 1]) - correction)
    }
    else CTABLE <- table(tab0$LBL)/length(tab0[, 1])
    CTABLE <- data.frame(CTABLE)
    names(CTABLE) <- c("LBL", "fr")
    if (trz.probability) 
        cat("# joint.prob OK\n")
    return(CTABLE)
}
