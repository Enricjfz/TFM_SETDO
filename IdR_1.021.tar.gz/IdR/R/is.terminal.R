is.terminal <-
function (node, i, MADY, trz.primitive = FALSE) 
{
    if (trz.primitive) 
        cat("is.terminal: ")
    if ((i < 1) | (i > dim(MADY)[1])) {
        cat("name: ", node$name, "  i: ", i, "\n")
        print.mady(MADY)
        stop("TERMINAL NODE")
    }
    terminal = (sum(MADY[i, ]) == 0)
    if (trz.primitive) 
        cat("is.terminal OK\n")
    invisible(terminal)
    return(terminal)
}
