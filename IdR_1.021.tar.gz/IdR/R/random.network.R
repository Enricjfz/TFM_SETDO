random.network <-
function (Nodes = 8, Domains = 2, Values = NULL, max.gr = 0, 
    mady = NULL, Probability = TRUE, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<random.network-")
    if (length(Nodes) == 1) {
        n <- Nodes
        NAMES <- c()
        for (i in 1:n) NAMES <- c(NAMES, paste("N", i, sep = ""))
    }
    else {
        n <- length(Nodes)
        NAMES <- Nodes
    }
    if (length(Domains) == 1) 
        d <- rep(Domains, n)
    else if (length(Domains) == n) 
        d <- Domains
    else stop("length(Domains) ", length(Domains))
    dmax <- max(d)
    if (length(Values) == 0) {
        Values <- matrix(data = rep("", n * dmax), nrow = n, 
            byrow = TRUE)
        for (i in 1:n) {
            for (j in 1:d[i]) Values[i, j] <- paste("V", j, NAMES[i], 
                sep = "")
        }
    }
    if (length(mady) == 0) 
        mady <- random.mady(n, max.gr)
    h.diag <- list()
    for (i in 1:n) {
        name <- NAMES[i]
        ROWS <- 1
        PREDS <- c()
        for (j in 1:n) if (mady[j, i] == CONDICIONAL()) {
            ROWS <- ROWS * d[j]
            PREDS <- c(PREDS, NAMES[j])
        }
        VALUES <- c()
        for (j in 1:d[i]) VALUES <- c(VALUES, Values[i, j])
        mx. <- NULL
        if (Probability) {
            dat <- sample(1:1000, ROWS * d[i], replace = TRUE)
            for (r in 1:ROWS) {
                pot <- dat[(1 + (r - 1) * d[i]):(d[i] * r)]
                prob <- pot/sum(pot)
                dat[(1 + (r - 1) * d[i]):(d[i] * r)] <- prob
            }
            if (sum(dat) != ROWS) {
                print(ROWS)
                print(sum(dat))
                print(dat)
                stop("<<<...............>>>")
            }
            mx. <- matrix(data = dat, nrow = ROWS, ncol = d[i], 
                byrow = TRUE, dimnames = NULL)
        }
        node. <- node(Type = "CHANCE", Name = NAMES[i], Values = VALUES, 
            Preds = PREDS, Pots = mx., Mpot = NULL)
        h.diag <- c(h.diag, list(node.))
    }
    names(h.diag) <- NAMES
    net <- bayesian.network.(h.diag, Probability = Probability)
    c.c(net, 0, "random.network")
    if (trz.definition) 
        cat("-random.network>")
    return(net)
}
