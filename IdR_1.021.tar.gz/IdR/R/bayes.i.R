bayes.i <-
function (id, node.i, node.j, Calc = TRUE, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("bayes.i ", node.i$name, " ---> ", node.j$name, "\n")
    BAYES <- c()
    if (Calc) {
        marginal.i <- node.i$pots
        nummarg <- length(node.i$values)
        numpots <- length(node.j$pots[, 1])
        if (node.j$preds[length(node.j$preds)] != node.i$name) {
            node.j <- rotacion.pots(id, node.j, c(node.i$name), 
                trz.probability = trz.evaluation)
        }
        marg.i <- c()
        for (i in 1:length(marginal.i[, 1])) marg.i <- c(marg.i, 
            rep(marginal.i[i, ], length(node.j$values)))
        marginal.i <- matrix(marg.i, ncol = nummarg, byrow = TRUE, 
            dimnames = NULL)
        conditional.j <- c()
        for (j in 1:(numpots/nummarg)) for (i in 1:length(node.j$pots[1, 
            ])) conditional.j <- c(conditional.j, node.j$pots[((j - 
            1) * nummarg + 1):(j * nummarg), i])
        conditional.j <- matrix(data = conditional.j + 9.9999999999999998e-13, 
            ncol = nummarg, byrow = TRUE, dimnames = NULL)
        for (i in 1:length(conditional.j[, 1])) {
            conditional.j[i, ] <- conditional.j[i, ] * marginal.i[i, 
                ]
            conditional.j[i, ] <- conditional.j[i, ]/sum(conditional.j[i, 
                ])
        }
        BAYES <- conditional.j
    }
    if (trz.evaluation) 
        cat("bayes.i: OK\n")
    return(BAYES)
}
