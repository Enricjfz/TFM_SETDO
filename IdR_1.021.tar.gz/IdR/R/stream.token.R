stream.token <-
function (vtkn, ncol = 10000000, quote = FALSE, tksep = ",", 
    trz.tables = FALSE) 
{
    if (trz.tables) 
        cat("<stream.token ")
    str <- ""
    if (length(vtkn) == 0) {
        return(str)
    }
    if (quote) {
        str <- paste(str, "\"", as.character(vtkn[1]), "\"", 
            sep = "")
    }
    else {
        str <- paste(str, as.character(vtkn[1]), sep = "")
    }
    if (length(vtkn) == 1) {
        return(str)
    }
    for (i in 2:length(vtkn)) if (quote) {
        str <- paste(str, tksep, " \"", as.character(vtkn[i]), 
            "\"", sep = "")
    }
    else {
        if ((i%%ncol) == 0) {
            str <- paste(str, tksep, as.character(vtkn[i]), "\n", 
                sep = "")
        }
        else {
            str <- paste(str, tksep, as.character(vtkn[i]), sep = "")
        }
    }
    if (trz.tables) {
        print(str)
        cat("stream.token: OK>\n")
    }
    return(str)
}
