node <-
function (Node = NULL, Type = NULL, Name = NULL, Values = NULL, 
    Preds = NULL, Pots = NULL, Mpot = NULL, Maxszpot = 0, EPSILON = 1e-25, 
    trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<node>")
    if (length(Node) != 0) {
        cpy.node <- list(type = Node$type, name = Node$name, 
            values = Node$values, preds = Node$preds, pots = Node$pots, 
            mpot = Node$mpot, maxszpot = Node$maxszpot)
        return(cpy.node)
    }
    if (!(Type %in% nodeTYPE())) 
        stop("Type?", Type)
    if (length(Name) < 1) 
        stop("Name?", Name)
    if (length(Values) == 1) {
        if (EPSILON == 0) 
            stop("Values?", Values)
        Values <- c(Values, "ELSE")
        Preds <- NULL
        Pots <- matrix(data = c(1 - EPSILON, EPSILON), nrow = 1, 
            ncol = 2, byrow = TRUE, dimnames = list(c(Name), 
                c(Values)))
    }
    if (length(Pots) == 0) {
        if (length(Preds) == 0) 
            Pots <- matrix(data = c(1/length(Values)), nrow = 1, 
                ncol = length(Values), byrow = TRUE, dimnames = list(c(Name), 
                  c(Values)))
        else stop("Pots?", Pots)
    }
    return(list(type = Type, name = Name, values = Values, preds = Preds, 
        pots = Pots, mpot = Mpot, maxszpot = max(Maxszpot, lengthpots = length(Pots[, 
            1]))))
}
