lbn <-
function (filename, tab0, nettype = "mbayes", noise = NULL, class.name = NULL, 
    maxnode.input = -1, laplace.correction = FALSE, time.out = 300, 
    trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("lbn: ")
    hayVARIABLES <- FALSE
    for (i in 1:dim(tab0)[2]) hayVARIABLES <- hayVARIABLES | 
        (length(levels(as.factor(tab0[, i]))) >= 2)
    if (trz.probability) 
        cat("lbn: hayVARIABLES: ", hayVARIABLES, "\n")
    if (hayVARIABLES) {
        sink(filename)
        cat("## Learning bayesian networks on R file: ", filename, 
            "   NETTYPE: ", nettype, "\n")
        cat("### ", dim(tab0)[1], " // ", names(tab0), " #\n", 
            sep = " ")
        for (i in 1:length(tab0[1, ])) cat("### ", length(levels(tab0[, 
            i])), " #\n", sep = " ")
        cat("require( IdR, quietly=FALSE) \n")
        cat("# Bayesian Network \n\n", sep = "")
        cat("cat( \"Bayesian Network    --  \", ", "\"", "bn", 
            "\"", ", \"\\n\")", "\n", sep = "")
        cat("\nbn", " = list( \n\n")
        if (nettype == "mbayes") 
            mbayes(tab0, laplace.correction = laplace.correction, 
                trz.probability = trz.probability)
        if (nettype == "nbayes") 
            nbayes(tab0, class.name, laplace.correction = laplace.correction, 
                trz.probability = trz.probability)
        if (nettype == "xbayes") 
            xbayes(tab0, noise, laplace.correction = laplace.correction, 
                time.out, trz.probability = trz.probability)
        cat(")\n\n")
        cat("bn", "<- bayesian.network.(", "bn", ")\n", sep = "")
        cat("cat( \"Bayesian Network    --  \", ", "\"", "bn", 
            "\"", ", \"\\n\")", "\n", sep = "")
        cat("dump.netG( bn)")
        cat("\n")
        sink()
    }
    else {
        if (trz.probability) 
            cat("lbn OK-2\n")
        return("")
    }
    if (trz.probability) 
        cat("lbn OK-1\n")
    return(filename)
}
