utility.node <-
function (id, STOP = TRUE, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<utility.node>")
    for (i in 1:length(id)) {
        if (is.utility(id[i][[1]])) {
            return(id[i][[1]])
        }
    }
    if (STOP) 
        stop("Non exist utility node. ")
    else return(NULL)
}
