meannod.eval <-
function (net, name = "netname", CALC = TRUE, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("MEANNOD.EVAL ")
    folder.manager()
    summary.network(net, name)
    net <- reset.eval(net)
    for (i in 1:length(net)) {
        if (is.chance(net[i][[1]])) 
            if (is.marginal(net[i][[1]])) {
                cat("Node: ", net[i][[1]]$name, " marginal node\n")
                print(net[i][[1]]$pots)
            }
            else {
                cat("Node: ", net[i][[1]]$name, " not marginal\n")
                cat("Preds: ", net[i][[1]]$preds, "\n")
                print(apply(net[i][[1]]$pots, 2, sum)/length(net[i][[1]]$pots[, 
                  1]))
            }
    }
    if (trz.evaluation) 
        print(mady(net))
    summary.network(net, name)
    if (trz.evaluation) 
        cat("MEANNOD.EVAL: OK\n")
    invisible(net)
}
