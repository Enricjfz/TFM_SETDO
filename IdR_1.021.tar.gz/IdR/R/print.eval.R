print.eval <-
function (net, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("#  print.eval \n")
    print(net)
    for (i in 1:length(net)) {
        if (is.chance(net[i][[1]])) 
            if (i < 10) 
                cat("#", i, " ----- ")
            else if (i < 100) 
                cat("#", i, " ---- ")
            else if (i < 1000) 
                cat("#", i, " --- ")
        cat(round(net[i][[1]]$mpot, digits = 4), "  ::--^--::  ", 
            net[i][[1]]$name, "\n")
        if (i < 10) 
            cat("#", i, " ------- ")
        else if (i < 100) 
            cat("#", i, " ------ ")
        else if (i < 1000) 
            cat("#", i, " ----- ")
        cat(net[i][[1]]$values, "  ::--|--::  ", net[i][[1]]$preds, 
            "\n")
    }
    if (trz.evaluation) 
        cat("#  print.eval: OK\n")
    return(net)
}
