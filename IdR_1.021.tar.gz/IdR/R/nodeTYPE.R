nodeTYPE <-
function () 
{
    return(c("DECISION", "UTILITY", "CHANCE", "DETERMINISTIC", 
        "xDECISION", "xUTILITY", "xCHANCE", "xDETERMINISTIC"))
}
