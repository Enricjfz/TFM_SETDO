decisions <-
function (net, V, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<decisions")
    DECISIONS <- c()
    if (length(V) == 0) {
        if (trz.definition) 
            cat("-decisions>")
        return(DECISIONS)
    }
    PHASE <- c()
    for (i in 1:length(V)) {
        node <- ann(net, V[i])
        if (is.decision(node)) {
            PHASE <- c(PHASE, node$Pots[1, 1])
            DECISIONS <- c(DECISIONS, V[i])
        }
    }
    if (trz.definition) 
        cat("-decisions>")
    if (length(PHASE) > 0) 
        return(DECISIONS[order(PHASE)])
    else return(DECISIONS)
}
