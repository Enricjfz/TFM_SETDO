network.sort <-
function (net, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<network.sort")
    S <- sort(names(net))
    net.sorted <- net
    I <- 1
    for (i in 1:length(net)) if (is.deterministic(net[i][[1]])) {
        node <- ann(net, S[i], STOP = FALSE)
        names(node) <- S[i]
        net.sorted[I][[1]] <- node
        I <- I + 1
    }
    for (i in 1:length(net)) if (is.chance(net[i][[1]])) {
        node <- ann(net, S[i], STOP = FALSE)
        names(node) <- S[i]
        net.sorted[I][[1]] <- node
        I <- I + 1
    }
    if (network.type(net) == "Influence diagram") 
        for (i in 1:length(net)) if (is.decision(net[i][[1]])) {
            node <- ann(net, S[i], STOP = FALSE)
            names(node) <- S[i]
            net.sorted[I][[1]] <- node
            I <- I + 1
        }
    if (network.type(net) == "Influence diagram") 
        for (i in 1:length(net)) if (is.utility(net[i][[1]])) {
            node <- ann(net, S[i], STOP = FALSE)
            names(node) <- S[i]
            net.sorted[I][[1]] <- node
            I <- I + 1
        }
    if (trz.definition) 
        cat("-network.sort>")
    return(net.sorted)
}
