idtobn <-
function (net, trz.definition = FALSE) 
{
    if (trz.definition) {
        MADY <- mady(net)
        print.mady(MADY)
    }
    for (i in 1:length(net)) {
        node <- net[i][[1]]
        NCOLS <- length(node$values)
        if (is.decision(node)) {
            new.node <- node(Node = NULL, Type = "CHANCE", Name = node$name, 
                Values = node$values, Preds = node$preds, Pots = NULL, 
                Mpot = matrix(rep(1/NCOLS, NCOLS), nrow = 1, 
                  ncol = NCOLS, byrow = TRUE, dimnames = NULL), 
                Maxszpot = NULL, trz.definition = FALSE)
            NROWS <- pots.size(net, new.node)
            new.node$pots <- matrix(rep(1/NCOLS, NROWS * NCOLS), 
                nrow = NROWS, ncol = NCOLS, byrow = TRUE, dimnames = NULL)
            net[index.id(net, node$name)][[1]] <- node(Node = new.node, 
                Type = NULL, Name = NULL, Values = NULL, Preds = NULL, 
                Pots = NULL, Mpot = NULL, Maxszpot = NULL, trz.definition = FALSE)
            print(new.node$name)
        }
        if (is.utility(node)) {
            new.node <- node(Node = NULL, Type = "CHANCE", Name = node$name, 
                Values = paste(rep("U", length(node$values)), 
                  node$values, sep = ""), Preds = node$preds, 
                Pots = NULL, Mpot = NULL, Maxszpot = NULL, trz.definition = FALSE)
            NROWS <- pots.size(net, new.node)
            node$pots <- node$pots - min(node$pots)
            node$pots <- node$pots/max(node$pots)
            dpU <- matrix(c(1 - node$pots, node$pots), nrow = 2, 
                ncol = NROWS, byrow = TRUE, dimnames = NULL)
            new.node$pots <- t(dpU)
            net[index.id(net, node$name)][[1]] <- node(Node = new.node, 
                Type = NULL, Name = NULL, Values = NULL, Preds = NULL, 
                Pots = NULL, Mpot = NULL, Maxszpot = NULL, trz.definition = FALSE)
            print(new.node$name)
        }
    }
    if (trz.definition) {
        MADY <- mady(net)
        print.mady(MADY)
    }
    return(net)
}
