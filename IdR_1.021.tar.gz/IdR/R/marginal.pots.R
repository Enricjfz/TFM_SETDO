marginal.pots <-
function (id, node, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("marginal.pots ", node$name, "\n")
    nv <- length(node$values)
    if (is.decision(node)) {
        DPots = matrix(data = c(1/nv), nrow = 1, ncol = nv, byrow = TRUE, 
            dimnames = NULL)
        if (trz.probability) 
            cat("marginal.pots: OK-0\n")
        return(DPots)
    }
    if (is.marginal(node)) {
        if (trz.probability) 
            cat("marginal.pots: OK-1\n")
        Pots <- node$pots
        return(Pots)
    }
    if (dim(as.matrix(node$mpot))[1] == 1 & sum(dim(as.matrix(node$mpot))) > 
        2) {
        if (trz.probability) 
            cat("marginal.pots: OK-2\n")
        Pots <- node$mpot
        return(Pots)
    }
    Preds <- node$preds
    Pots <- node$pots
    for (i in length(Preds):1) {
        node.i <- ann(id, Preds[i])
        marginal.i <- marginal.pots(id, node.i)
        numpots <- length(Pots[, 1])
        nummarg <- length(marginal.i)
        if (Preds[length(Preds)] == node.i$name) {
            Pots <- as.matrix(Pots[1:numpots, ]) * rep(as.matrix(marginal.i), 
                numpots/nummarg)
            Pots <- suma.potencial(Pots, nummarg)
            Pots <- matrix(data = Pots, nrow = numpots/nummarg, 
                ncol = nv, byrow = TRUE, dimnames = NULL)
            Preds <- remove.name(Preds, node.i$name)
        }
        else {
            cat("node$preds:", Preds, "\n")
            cat("node.i$preds:", node.i$name, "\n")
            stop("orden dims")
        }
    }
    if (trz.probability) 
        cat("marginal.pots: OK-3\n")
    return(Pots)
}
