netMap <-
function (net, filename = "net", classMap = "adyacency", save = "YES", 
    trz.definition = FALSE) 
{
    pszW <- 8.75
    pszH <- 10.5
    if (trz.definition) 
        cat("<netMap")
    nodes <- names(net)
    if (classMap == "adyacency") {
        m <- mady(net)
        type = "image"
    }
    if (classMap == "influence") {
        if (require(lattice, quietly = FALSE)) {
            m <- minf(net)
            type = "levelplot"
        }
        else {
            cat("Package ''lattice'' is not loaded.\n")
        }
    }
    m <- matrix(data = m, nrow = length(net), ncol = length(net), 
        byrow = FALSE, dimnames = list(paste(names(net), 1:length(net)), 
            paste(names(net), 1:length(net))))
    if (save == "YES") {
        postscript(paste(idr.output.eval(), "netMap-", "net-", 
            filename, ".eps", sep = ""), horizontal = FALSE, 
            width = pszW, height = pszH)
        if (type == "image") 
            plt <- image(m, xlab = "Nodes", ylab = "Nodes", main = classMap)
        if (type == "levelplot") 
            plt <- levelplot(m, xlab = "Nodes", ylab = "Nodes", 
                main = classMap)
        dev.off()
    }
    if (trz.definition) 
        cat("-netMap>")
    invisible(m)
}
