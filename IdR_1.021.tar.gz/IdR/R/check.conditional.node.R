check.conditional.node <-
function (id, node, EPSILON = 9.9999999999999995e-08, error = FALSE, 
    trz.probability = FALSE) 
{
    sz.check <- 4096
    sz <- length(node$values)
    if ((sz * pots.size(id, node)) != length(node$pots)) {
        cat("\nNode: ", node$name, "\n")
        cat("sz * pots.size( id, node): ", node$name, "   ", 
            sz * pots.size(id, node), "\n")
        cat("length( node$pots): ", length(node$pots), "\n")
        cat("condit.node not fit.sz", "\n")
        error <- TRUE | error
    }
    else {
        numpots <- (length(node$pots)/sz)
        for (k in sort(sample(1:numpots, min(sz.check, numpots)))) if (EPSILON > 
            0) {
            if (sum(node$pots[k, ]) - 1 > EPSILON) {
                if (trz.probability) {
                  cat("\nNode: ", node$name, "  pot: ", k, "\n")
                  print(node$pots[k, ])
                  cat("condit.node not sum.1.0", "\n")
                }
                error <- TRUE | error
            }
        }
    }
    return(error)
}
