inst.potential <-
function (id, node, value, trz.evaluation = FALSE) 
{
    INDEP.COND. <- 0
    CONDICIONAL <- 1
    INFORMATIVO <- 2
    I <- index.id(id, node$name)
    if (is.marginal(node)) {
        cat("MARGINAL NODE, name: ", node$name, "   preds: ", 
            node$preds, "\n")
        node$pots <- matrix(data = rep(0, length(node$values)), 
            nrow = 1, ncol = length(node$values), byrow = TRUE, 
            dimnames = NULL)
        node$pots[which(node$values == value)] <- 1
        node$mpots <- matrix(data = rep(0, length(node$values)), 
            nrow = 1, ncol = length(node$values), byrow = TRUE, 
            dimnames = NULL)
        node$mpots[which(node$values == value)] <- 1
        for (j in 1:length(id)) {
            MADY <- mady(id)
            if (MADY[I, j] == CONDICIONAL) {
                print("CONDICIONAL")
                jump <- which(node$values == value)
                cat("jump:", jump, "\n")
                pszj <- pots.size(id, id[j][[1]])
                cat("pszj:", pszj, "\n")
                if (id[j][[1]]$preds[1] != node$name) {
                  remain <- id[j][[1]]$preds
                  remain <- remove.name(remain, node$name)
                  id[j][[1]] <- rotacion.pots(id, id[j][[1]], 
                    c(node$name, remain))
                }
                if (is.utility(id[j][[1]])) {
                  print("is.utility  name.j: ", id[j][[1]]$name, 
                    "  preds.j:", id[j][[1]]$preds, "\n")
                  lpi <- (1 + 1 * pszj * (jump - 1))
                  lps <- lpi + (1 * pszj) - 1
                  new.data <- as.vector(t(id[j][[1]]$pots))[lpi:lps]
                  id[j][[1]]$pots <- matrix(data = new.data, 
                    nrow = pszj/length(node$values), ncol = 1, 
                    byrow = TRUE, dimnames = NULL)
                }
                else if (is.chance(id[j][[1]])) {
                  cat("is.chance  name.j: ", id[j][[1]]$name, 
                    "  preds.j:", id[j][[1]]$preds, "\n")
                  print(id[j][[1]]$pots)
                  cvj <- length(id[j][[1]]$values)
                  cat("cvj:", cvj, "\n")
                  lpi <- (1 + cvj * (pszj/length(node$values)) * 
                    (jump - 1))
                  lps <- lpi + (cvj * (pszj/length(node$values))) - 
                    1
                  cat("lpi:", lpi, "  lps:", lps, "\n")
                  new.data <- as.vector(t(id[j][[1]]$pots))[lpi:lps]
                  id[j][[1]]$pots <- matrix(data = new.data, 
                    nrow = pszj/length(node$values), ncol = cvj, 
                    byrow = TRUE, dimnames = NULL)
                  print(id[j][[1]]$pots)
                }
                else stop("is.utility/is.chance/??")
                id[j][[1]]$preds <- remove.name(id[j][[1]]$preds, 
                  node$name)
            }
            else if (MADY[I, j] == INFORMATIVO) {
                print("INFORMATIVO")
                id[j][[1]]$preds <- remove.name(id[j][[1]]$preds, 
                  node$name)
            }
        }
    }
    if (!is.marginal(node)) {
        cat("NOT MARGINAL NODE, name: ", node$name, "   preds: ", 
            node$preds, "\n")
        cat("n pots: ", length(id[I][[1]]$pots[, 1]), " --- \n")
        rnodes <- sample(1:length(id))
        ia.count <- 0
        for (j in rnodes) {
            cat("node j: ", j, "\n")
            MADY <- mady(id)
            if (is.chance(id[j][[1]]) && (MADY[j, I] == CONDICIONAL)) {
                cat("\n[try to reversal arc from: ", id[j][[1]]$name, 
                  "]\n")
                cat("[to: ", id[I][[1]]$name, "OK]\n")
                id <- ia(id, id[j][[1]], id[I][[1]])
                if (trz.evaluation) 
                  MADY <- mady(id)
                if (trz.evaluation) 
                  print(MADY)
                if (trz.evaluation) 
                  print(id[I])
                cat("n pots: ", length(id[I][[1]]$pots[, 1]), 
                  " --- \n")
                ia.count <- ia.count + 1
            }
        }
        if (ia.count == 0) 
            stop("ia.count == 0")
        else cat("ia.count: ", ia.count, "\n")
        if (is.marginal(id[I][[1]])) {
            cat("preds: ", id[I][[1]]$preds, "\n")
            return(inst.potential(id, id[I][[1]], value))
        }
        else {
            cat("Warning\n")
            return(inst.potential(id, id[I][[1]], value))
        }
    }
    return(id)
}
