sortPreds <-
function (net, Preds) 
{
    if (length(Preds) > 1) 
        for (i in 1:(length(Preds) - 1)) {
            for (j in (i + 1):(length(Preds))) {
                if (length(ann(net, Preds[i], STOP = TRUE)$preds) > 
                  length(ann(net, Preds[j], STOP = TRUE)$preds)) {
                  name <- Preds[i]
                  Preds[i] <- Preds[j]
                  Preds[j] <- name
                }
            }
        }
    return(Preds)
}
