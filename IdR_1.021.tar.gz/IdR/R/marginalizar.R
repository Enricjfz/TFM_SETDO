marginalizar <-
function (net, i, Calc = TRUE, Marg = "node", Simple = "NONE", 
    trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("#  marginalization ")
    count.while <- 0
    max.while <- 2 * length(net)
    while (!is.marginal(net[i][[1]], Calc = TRUE, trz.probability = trz.evaluation) & 
        (count.while < max.while)) {
        Preds <- sortPreds(net, net[i][[1]]$preds)
        for (name in Preds) {
            node.j <- ann(net, name, trz.definition = trz.evaluation, 
                STOP = TRUE)
            net <- ia(net, node.j, net[i][[1]], CALC = Calc, 
                trz.evaluation = trz.evaluation)
            if (length(node.j$preds) > 12) 
                net <- simple.network(net, index.id(net, node.j$name), 
                  simple = Simple, trz.definition = trz.evaluation)
            if (length(node.j$preds) > 12) 
                cat("#  WARNING   Node j: ", node.j$name, "  Preds: ", 
                  length(node.j$preds), "\n")
            if (length(net[i][[1]]$preds) > 12) 
                net <- simple.network(net, index.id(net, net[i][[1]]$name), 
                  simple = Simple, trz.definition = trz.evaluation)
            if (length(net[i][[1]]$preds) > 12) 
                cat("#  WARNING   Node i: ", net[i][[1]]$name, 
                  "  Preds: ", length(net[i][[1]]$preds), "\n")
        }
        cat("#  Preds:* ", net[i][[1]]$preds, "\n")
        count.while <- count.while + 1
        if (Marg == "network") 
            net <- simple.network(net, node = 0, simple = Simple, 
                trz.definition = trz.evaluation)
    }
    if (!is.marginal(net[i][[1]], Calc = TRUE, trz.probability = trz.evaluation)) {
        cat("....    WARNING marnod.eval, marginal? ", net[i][[1]]$name, 
            " -:::- ", net[i][[1]]$preds, "    zzzzzzz\n")
    }
    cat("Node:-: ", net[i][[1]]$name, "  Count.While", count.while, 
        "\n")
    if (is.marginal(net[i][[1]], trz.probability = trz.evaluation)) {
        if (trz.evaluation) 
            cat("#  Node:-: ", net[i][[1]]$name, "\n")
        net[i][[1]]$mpot = net[i][[1]]$pots
        if (trz.evaluation) 
            cat("#  <<<<    ", as.vector(net[i][[1]]$pots), "    >>>>\n")
        if (trz.evaluation) 
            summary.network(net, net[i][[1]]$name, trz.definition = trz.evaluation)
    }
    if (trz.evaluation) 
        cat("#  marginalization: OK\n")
    if (Marg == "node") 
        return(net[i][[1]]$mpot)
    else if (Marg == "network") 
        return(net)
    else stop("Marg?:", Marg)
}
