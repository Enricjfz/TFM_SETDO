discretizeNode <-
function (node, nlevels = 5, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<discretizeNode>")
    if (node$type == nodeTYPEc()[1]) {
    }
    if (node$type == nodeTYPEc()[2]) {
    }
    if (node$type == nodeTYPEc()[3]) {
    }
    if (node$type == nodeTYPEc()[4]) {
    }
    return(node)
}
