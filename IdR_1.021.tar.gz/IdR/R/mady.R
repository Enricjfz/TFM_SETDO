mady <-
function (id, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<mady")
    if (length(id) < 1) {
        stop("-not exists network")
    }
    MADY <- matrix(data = rep(INDEP.COND_(), length(id) * length(id)), 
        nrow = length(id), ncol = length(id), byrow = TRUE, dimnames = list(names(id), 
            names(id)))
    if (length(id) == 1) {
        if (trz.definition) 
            cat("-mady>")
        net.type <- network.type(id)
        if (net.type == "Influence diagram") 
            if (is.utility(id[1][[1]])) {
                return(MADY)
            }
            else {
                print("Begin{network}-------")
                print(id)
                print("End{network}-------")
                stop("-not utility node")
            }
        return(MADY)
    }
    for (i in 1:length(id)) {
        for (j in 1:length(id)) {
            if (length(id[j][[1]]$preds) > 0) 
                for (k in 1:length(id[j][[1]]$preds)) {
                  if (id[i][[1]]$name == id[j][[1]]$preds[k]) {
                    if (i == j) 
                      stop("i==j, i:", i)
                    if (is.decision(id[j][[1]])) 
                      MADY[i, j] <- INFORMATIVO()
                    else MADY[i, j] <- CONDICIONAL()
                  }
                }
        }
    }
    if (trz.definition) 
        cat("-mady>")
    return(MADY)
}
