x5.sbn <-
function (bn, tab0, ssz, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# x5.sbn: ")
    namevars <- names(tab0)
    sampledvars <- c()
    feature.node <- NULL
    i.sample <- NULL
    bn.simu <- NULL
    while (length(sampledvars) < length(namevars)) for (i.name in 1:length(namevars)) if (!(namevars[i.name] %in% 
        sampledvars)) {
        feature.node <- ann(bn, namevars[i.name], trz.definition = trz.probability)
        if (length(feature.node$preds) == 0) {
            i.sample <- sample(feature.node$values, size = ssz, 
                replace = TRUE, prob = feature.node$pots[1, ])
        }
        else if (prod(feature.node$preds %in% sampledvars) == 
            1) {
            LABELS1 <- names(table(tab0[, feature.node$preds[1]]))
            if (length(feature.node$preds) > 1) {
                LABELS2 <- names(table(tab0[, feature.node$preds[2]]))
            }
            if (length(feature.node$preds) > 2) {
                LABELS3 <- names(table(tab0[, feature.node$preds[3]]))
            }
            if (length(feature.node$preds) > 3) {
                LABELS4 <- names(table(tab0[, feature.node$preds[4]]))
            }
            if (length(feature.node$preds) > 4) {
                LABELS5 <- names(table(tab0[, feature.node$preds[5]]))
            }
            for (j in 1:ssz) {
                if (length(feature.node$preds) == 1) {
                  k1 <- which(LABELS1 == bn.simu[j, feature.node$preds[1]])
                  k <- k1
                }
                else if (length(feature.node$preds) == 2) {
                  k1 <- which(LABELS1 == bn.simu[j, feature.node$preds[1]])
                  k2 <- which(LABELS2 == bn.simu[j, feature.node$preds[2]])
                  k <- k1 + (k2 - 1) * length(LABELS1)
                }
                else if (length(feature.node$preds) == 3) {
                  k1 <- which(LABELS1 == bn.simu[j, feature.node$preds[1]])
                  k2 <- which(LABELS2 == bn.simu[j, feature.node$preds[2]])
                  k3 <- which(LABELS3 == bn.simu[j, feature.node$preds[3]])
                  k <- k1 + (k2 - 1) * length(LABELS1) + (k3 - 
                    1) * length(LABELS1) * length(LABELS2)
                }
                else if (length(feature.node$preds) == 4) {
                  k1 <- which(LABELS1 == bn.simu[j, feature.node$preds[1]])
                  k2 <- which(LABELS2 == bn.simu[j, feature.node$preds[2]])
                  k3 <- which(LABELS3 == bn.simu[j, feature.node$preds[3]])
                  k4 <- which(LABELS4 == bn.simu[j, feature.node$preds[4]])
                  k <- k1 + (k2 - 1) * length(LABELS1) + (k3 - 
                    1) * length(LABELS1) * length(LABELS2) + 
                    (k4 - 1) * length(LABELS1) * length(LABELS2) * 
                      length(LABELS3)
                }
                else if (length(feature.node$preds) == 5) {
                  k1 <- which(LABELS1 == bn.simu[j, feature.node$preds[1]])
                  k2 <- which(LABELS2 == bn.simu[j, feature.node$preds[2]])
                  k3 <- which(LABELS3 == bn.simu[j, feature.node$preds[3]])
                  k4 <- which(LABELS4 == bn.simu[j, feature.node$preds[4]])
                  k5 <- which(LABELS5 == bn.simu[j, feature.node$preds[5]])
                  k <- k1 + (k2 - 1) * length(LABELS1) + (k3 - 
                    1) * length(LABELS1) * length(LABELS2) + 
                    (k4 - 1) * length(LABELS1) * length(LABELS2) * 
                      length(LABELS3)
                  +(k5 - 1) * length(LABELS1) * length(LABELS2) * 
                    length(LABELS3) * length(LABELS4)
                }
                i.sample <- c(i.sample, sample(feature.node$values, 
                  size = 1, replace = TRUE, prob = feature.node$pots[k, 
                    ]))
            }
        }
        if (length(i.sample) != 0) 
            if (length(bn.simu) == 0) {
                bn.simu <- data.frame(i.sample)
                names(bn.simu) <- namevars[i.name]
            }
            else {
                sampledvars <- c(namevars[i.name], names(bn.simu))
                bn.simu <- cbind(i.sample, bn.simu)
                names(bn.simu) <- sampledvars
            }
        i.sample <- NULL
    }
    if (trz.probability) 
        cat("# x5.sbn OK\n")
    return(bn.simu[, namevars])
}
