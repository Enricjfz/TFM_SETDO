ORGate <-
function (levels, dimensions, params, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("ORGate ")
    data.pots <- rep(1/levels, levels * prod(dimensions))
    if (trz.probability) 
        cat("ORGate: OK\n")
    return(data.pots)
}
