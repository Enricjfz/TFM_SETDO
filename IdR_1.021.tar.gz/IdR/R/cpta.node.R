cpta.node <-
function (net, name = "netname", node = 0, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("<cpta.node")
    if (node == 0) 
        for (i in 1:length(net)) if (is.chance(net[i][[1]])) {
            dump.tpc(net, CALC = TRUE, net[i][[1]])
        }
        else {
            if (is.chance(net[node][[1]])) 
                dump.tpc(net, CALC = TRUE, net[node][[1]])
        }
    if (trz.probability) 
        cat("...cpta.node>\n")
    return(node)
}
