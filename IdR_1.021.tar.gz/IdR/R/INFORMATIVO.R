INFORMATIVO <-
function () 
{
    return(2)
}
