rs <-
function (id, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("<rs")
    if (length(id) <= 1) {
        if (is.utility(id[1][[1]])) {
            if (trz.evaluation) 
                cat("-rs>")
            return(id)
        }
        else {
            stop("-last node not utility.")
        }
    }
    repeat {
        node.list <- c()
        haySum <- FALSE
        MADY <- mady(id)
        nodes <- length(id)
        for (i in 1:nodes) {
            if ((sum(MADY[i, ]) > 0) || is.utility(id[i][[1]])) 
                node.list <- c(node.list, i)
            else haySum <- TRUE
        }
        id <- id[node.list]
        if (!haySum) 
            break
    }
    if (trz.evaluation) 
        cat("-rs>")
    return(id)
}
