KLDiv <-
function (pots, EPSILON = 1e-25) 
{
    lp <- length(pots[, 1])
    kldivergence <- rep(0, lp * (lp - 1)/2)
    k <- 1
    for (i in 1:(lp - 1)) for (j in (i + 1):(lp)) {
        p <- pots[i, ] + EPSILON
        p <- p/sum(p)
        q <- pots[j, ] + EPSILON
        q <- q/sum(q)
        kldivergence[k] <- min(sum(p * log2(p/q)), sum(q * log2(q/p)))
        k <- k + 1
    }
    return(kldivergence)
}
