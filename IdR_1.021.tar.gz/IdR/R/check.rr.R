check.rr <-
function (id, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<check.rr")
    if (length(id) > 1) {
        dups.names(id)
        dups.values(id)
        c.c(id, node = 0, msg = "check.rr", trz.definition = FALSE)
    }
    net.type <- network.type(id)
    if (net.type == "Influence diagram") {
        id <- rs(id)
        V <- 0
        name <- ""
        index.U <- -1
        for (i in 1:length(id)) {
            if (is.utility(id[i][[1]])) {
                V <- V + 1
                name <- id[i][[1]]$name
                index.U <- i
            }
        }
        if (V > 1) {
            cat("-Utility nodes: ", V, "\n")
            stop("Several utility nodes.  ")
        }
        if (trz.definition) 
            cat("-Utility node: ", name, "\n")
        if (sum(mady(id)[index.U, ]) != 0) {
            stop("Non terminal utility node")
        }
        if (length(id) == 1) {
            if (trz.definition) 
                cat("-check.rr>")
            return(id)
        }
        list.name <- c()
        for (i in 1:length(id)) {
            if (is.decision(id[i][[1]])) {
                list.name <- c(list.name, id[i][[1]]$name)
            }
        }
        if (length(list.name) > 0) {
            if (trz.definition) 
                cat("Decision nodes: ", list.name, "\n")
            MADY <- mady(id)
            for (i in 1:length(list.name)) {
                PREDS <- sp(id, ann(id, list.name[i]), MADY)
                PREDS <- decisions(id, PREDS)
                if (ann(id, list.name[i])$pots[1] != length(PREDS) + 
                  1) {
                  cat("-Decision: ", list.name[i], "  Predecessors: ", 
                    PREDS, "\n")
                  cat("Phase: ", ann(id, list.name[i])$pots[1], 
                    " != ", (length(PREDS) + 1), "\n")
                  stop("Non ordered decision sequence.")
                }
            }
        }
    }
    if (trz.definition) 
        cat("-check.rr>")
    return(id)
}
