MDL <-
function (net, trz.probability = FALSE) 
{
    mdl <- 0
    for (i in 1:length(net)) mdl <- mdl + length(net[i][[1]]$preds)
    mdl <- mdl * log(length(net))
    for (i in 1:length(net)) mdl <- mdl + 64 * pots.size(net, 
        net[i][[1]])/length(net[i][[1]]$values) * (length(net[i][[1]]$values) - 
        1)
    return(mdl)
}
