is.marginal <-
function (node, Calc = TRUE, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("#  is.marginal: ")
    marginal = (length(node$preds) == 0)
    if (Calc) 
        if (marginal && (length(node$pots[, 1]) != 1)) {
            cat("name: ", node$name, "\n")
            print(node$pots)
            stop("*Preds: |<", node$preds, ">|  num pots: ", 
                length(node$pots[, 1]), "  name: ", node$name)
        }
    if (!Calc) 
        if (marginal && (length(node$mpot) != length(node$values))) {
            cat("name: ", node$name, "\n")
            print(node$mpot)
            stop("**Preds: |<", node$preds, ">|  marg pots: ", 
                length(node$mpot), "  name: ", node$name)
        }
    if (trz.probability) 
        cat("OK\n")
    invisible(marginal)
}
