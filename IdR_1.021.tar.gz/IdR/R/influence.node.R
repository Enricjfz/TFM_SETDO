influence.node <-
function (net, node.i, node.j, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<influence.node>")
    vals <- length(node.i$values)
    blocks <- length(node.j$pots[, 1])/vals
    node.j <- rotacion.pots(net, node.j, c(node.i$name))
    RR <- relevant(node.j, vals, blocks)
    return(RR)
}
