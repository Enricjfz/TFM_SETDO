inv.fd <-
function (id, nodes.index, preds.weights, offset, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("inv.fd ")
    offset <- offset - 1
    index <- c()
    offset.i <- 0
    for (i in 1:length(nodes.index)) {
        index <- c(index, (offset - offset.i)%/%preds.weights[i])
        offset.i <- sum(index[1:i] * preds.weights[1:i])
    }
    indx.preds.values <- rep("z", length(nodes.index))
    for (i in 1:length(nodes.index)) {
        node <- id[nodes.index[i]][[1]]
        if ((index[i] + 1) %in% (1:length(node$values))) {
            indx.preds.values[i] <- node$values[index[i] + 1]
        }
        else {
            print(nodes.index)
            cat(preds.weights, "\n")
            stop("OVF  ", offset, "  ", i, "  ", index + 1, "  ", 
                length(node$values))
        }
    }
    if (trz.probability) 
        cat("inv.fd: OK\n")
    return(indx.preds.values)
}
