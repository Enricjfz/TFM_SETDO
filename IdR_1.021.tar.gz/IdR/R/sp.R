sp <-
function (id, node, MADY, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<sp")
    n <- length(id)
    PREDS <- c()
    j <- index.id(id, node$name)
    hay <- FALSE
    for (i in 1:n) if (MADY[i, j] != INDEP.COND_()) {
        PREDS <- c(PREDS, i)
        hay <- TRUE
    }
    while (hay) {
        for (k in PREDS) {
            hay <- FALSE
            for (i in 1:n) if (MADY[i, k] != INDEP.COND_()) 
                if (!esta(i, PREDS)) {
                  PREDS <- c(PREDS, i)
                  hay <- TRUE
                }
        }
    }
    if (trz.definition) 
        cat("-sp>")
    if (length(PREDS) == 0) 
        return(PREDS)
    else return(names.id(id, PREDS))
}
