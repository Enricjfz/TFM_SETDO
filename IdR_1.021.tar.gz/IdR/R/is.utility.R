is.utility <-
function (node, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<is.utility>")
    return(node$type == "UTILITY")
}
