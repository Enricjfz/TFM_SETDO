node.sort <-
function (net, node, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<node.sort")
    Sorted.preds <- sort(node[[1]]$preds)
    name <- names(node)
    if (!is.decision(node[[1]])) 
        if (length(node[[1]]$preds) > 1) {
            node <- rotacion.pots(net, node[[1]], Sorted.preds)
            names(node) <- name
        }
    if (trz.definition) 
        cat("-node.sort>")
    return(node)
}
