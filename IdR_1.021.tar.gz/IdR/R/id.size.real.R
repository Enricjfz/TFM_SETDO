id.size.real <-
function (id, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<id.size.real")
    node <- utility.node(id, STOP = FALSE)
    if (length(node) == 0) 
        size <- 0
    else size <- length(node$pots)
    for (i in 1:length(id)) {
        if (is.chance(id[i][[1]])) 
            size <- size + length(id[i][[1]]$pots)
        if (is.decision(id[i][[1]])) 
            size <- size + 1
    }
    if (trz.definition) 
        cat("-id.size.real>\n")
    return(size)
}
