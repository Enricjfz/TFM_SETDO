dump.tpc <-
function (id, CALC = TRUE, node.C, node.U = NULL, NumClusters = 5, 
    EU.KL = "EU", trz.primitive = FALSE) 
{
    prefix.eq <- paste("tpc-kbm2l-", NumClusters, "-", sep = "")
    schema.tpc <- function(id, node.C, NUMCLUSTERS) {
        cat("Chance node: ", node.C$name, " schema\n")
        sink(paste(idr.output.eval(), prefix.eq, node.C$name, 
            ".eq", sep = ""))
        cat(";Chance: ", node.C$name, "\n;Preds chance node: ", 
            node.C$name, " <", node.C$preds, ">\n")
        cat("File: ", paste(prefix.eq, node.C$name, sep = ""), 
            ";\n")
        cat("S: ", (sample(1000, 1)), paste(node.C$name, 0, sep = ""), 
            NUMCLUSTERS, ";\n")
        cat("Val: ", paste(rep(node.C$name, NUMCLUSTERS), "s", 
            1:NUMCLUSTERS, sep = ""), ";\n")
        for (i in 1:length(node.C$preds)) {
            node <- ann(id, node.C$preds[i])
            cat("Att: ", (sample(1000, 1)), node$name, length(node$values), 
                ";\n")
            cat("Val: ", node$values, ";\n")
        }
        sink()
        return(NUMCLUSTERS)
    }
    header.tpc <- function(id, node.C) {
        sink(paste(idr.output.eval(), prefix.eq, node.C$name, 
            ".hkb", sep = ""))
        cat("File: ", paste(prefix.eq, node.C$name, sep = ""), 
            ".txt ; \n", sep = "")
        cat("Head:", length(node.C$values), 1, length(node.C$preds), 
            " ;rst\n")
        cat("R: ", paste(length(node.C$preds) + (1:length(node.C$values))), 
            " ;\n")
        cat("S: ", length(node.C$preds), " ;\n")
        cat("T: ", 0:(length(node.C$preds) - 1), " ;\n")
        cat("Dom: ")
        for (i in 1:length(node.C$preds)) cat(length(ann(id, 
            node.C$preds[i])$values), " ")
        cat(" ;\n")
        cat("Bas: ")
        for (i in 1:length(node.C$preds)) cat((i - 1), " ")
        cat(" ;\n")
        cat("Rol: ")
        for (i in 1:length(node.C$preds)) cat((-1), " ")
        cat(" ;")
        sink()
        return("rst")
    }
    if (trz.primitive) 
        if (length(node.U) >= 0) {
            cat("file.tpc ")
            if (length(node.U$preds) == 0) {
                if (trz.primitive) 
                  cat("file.tpc: OK-1\n")
                return(node.U$name)
            }
            if (node.U$preds[length(node.U$preds)] != node.C$name) 
                node.U <- rotacion.pots(id, node.U, c(node.C$name))
            cat("Chance node: ", node.C$name, "\n")
            sink(paste(idr.output.eval(), prefix.eq, node.C$name, 
                node.U$name, ".eq", sep = ""))
            cat(";Chance: ", node.C$name, "\n;Preds utility node: ", 
                node.U$name, " <", node.U$preds, ">\n")
            cat("File: ", paste("", node.C$name, sep = ""), ";\n")
            cat("S: ", (sample(1000, 1)), node.C$name, length(node.C$values), 
                ";\n")
            cat("Val: ", node.C$values, ";\n")
            for (i in 1:length(node.U$preds)) {
                node <- ann(id, node.U$preds[i])
                cat("Att: ", (sample(1000, 1)), node.U$preds[i], 
                  length(node$values), ";\n")
                cat("Val: ", node$values, ";\n")
            }
            sink()
            if (CALC) {
                write.table(as.vector(round(node.U$pots, digits = 5)), 
                  file = paste(idr.output.eval(), prefix.eq, 
                    node.C$name, node.U$name, ".tpc", sep = ""), 
                  append = FALSE, quote = FALSE, sep = "\t", 
                  eol = "\n", dec = ".", row.names = FALSE, col.names = TRUE)
                Grid <- mdgrid(id, node.U)
                GRID <- data.frame(Grid, round(node.U$pots, digits = 7))
                names(GRID) <- c(names(Grid), "Utility")
                write.table(GRID, file = paste(idr.output.eval(), 
                  prefix.eq, node.C$name, node.U$name, ".txt", 
                  sep = ""), append = FALSE, quote = FALSE, sep = "\t", 
                  eol = "\n", dec = ".", row.names = FALSE, col.names = TRUE)
            }
        }
    if (!is.chance(node.C)) 
        stop(node.C$name, " not is a chance node.")
    check.mx(id, index.id(id, node.C$name))
    if (length(node.C$preds) <= 1) {
        return(node.C$name)
    }
    NUMCLUSTERS <- min(NumClusters, log2(length(node.C$preds) * 
        length(node.C$pots[, 1])))
    schema.tpc(id, node.C, NUMCLUSTERS)
    cat("Chance node: ", node.C$name, " header\n")
    header.tpc(id, node.C)
    if (CALC) {
        write.table(as.vector(round(node.C$pots, digits = 3)), 
            file = paste(idr.output.eval(), prefix.eq, node.C$name, 
                ".tpc", sep = ""), append = FALSE, quote = FALSE, 
            sep = "\t", eol = "\n", dec = ".", row.names = FALSE, 
            col.names = TRUE)
        Grid <- mdgrid(id, node.C)
    }
    if (trz.primitive) 
        cat("file.tpc: OK\n")
}
