remnod.eval <-
function (id, CALC = TRUE, ELTOS = 10, DUMP = FALSE, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("REMNOD.EVAL ")
    folder.manager()
    if (trz.evaluation) 
        cat("REMNOD.EVAL: OK\n")
    return(id)
}
