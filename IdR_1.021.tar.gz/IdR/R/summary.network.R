summary.network <-
function (net, name = "netname", verbose = "NO", trz.definition = FALSE) 
{
    if (verbose != "NO") 
        c.c(net, 0, "summary.network")
    n <- length(net)
    MADY <- mady(net)
    cat("Network summary:", name, "  Nodes: ", n, "\n")
    if (network.type(net) == "Bayesian network") {
        cat("Arcs: ", sum(MADY), "   ")
        cat("Max preds: ", max(apply(MADY, 2, sum)), "   ")
        cat("Max succs: ", max(apply(MADY, 1, sum)), "\n")
    }
    maxCX <- 0
    totCX <- 0
    maxszpot <- 0
    for (i in 1:n) {
        node <- net[i][[1]]
        gr <- length(node$preds)
        ROWS <- 1
        for (j in 1:n) if (MADY[j, i] == CONDICIONAL()) 
            ROWS <- ROWS * length(net[j][[1]]$values)
        cx <- length(node$values) * ROWS
        if (cx > maxCX) 
            maxCX <- cx
        totCX <- totCX + cx
        if (verbose != "NO") 
            if (network.type(net) == "Influence diagram") 
                cat("Node: ", node$name, "\n\t  Type: ", node$type, 
                  "\t  gr: ", gr, "\t  COMPLEX", cx, "\t  Preds: ", 
                  node$preds, "\n")
        if (verbose != "NO") 
            if (network.type(net) == "Bayesian network") 
                cat("Node: ", node$name, "\n\t  gr: ", gr, "\t  COMPLEX", 
                  cx, "\t  Preds: ", node$preds, "\n")
        maxszpot <- maxszpot + net[i][[1]]$maxszpot
    }
    if (verbose != "NO") 
        print.mady(MADY)
    cat("Maxszpot: ", maxszpot, "\n")
    cat("TOTAL COMPLEX: ", totCX, "  MAX COMPLEX: ", maxCX, "\n")
    return(totCX)
}
