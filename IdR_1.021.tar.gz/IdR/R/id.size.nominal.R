id.size.nominal <-
function (id, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<id.size.nominal")
    size <- 0
    for (i in 1:length(id)) {
        if (is.utility(id[i][[1]])) 
            size <- size + pots.size(id, id[i][[1]], trz.definition)
        if (is.chance(id[i][[1]])) 
            size <- size + pots.size(id, id[i][[1]], trz.definition) * 
                length(id[i][[1]]$values)
        if (is.decision(id[i][[1]])) 
            size <- size + 1
    }
    if (trz.definition) 
        cat("-id.size.nominal>\n")
    return(size)
}
