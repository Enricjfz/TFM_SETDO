relevant <-
function (node, v, b, trz.definition = FALSE) 
{
    RR <- 0
    for (q in 1:b) {
        RR. <- mean(abs(as.vector(t(node$pots[(1 + v * (q - 1)):(v * 
            q), ])) - rep(node$pots[(v * q), ], v)))
        RR <- max(RR, RR.)
    }
    return(RR)
}
