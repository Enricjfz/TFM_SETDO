klDivergence <-
function (p.pots, q.pots, EPSILON = 1e-25) 
{
    p <- p.pots
    q <- q.pots
    DIFFp <- 0
    i <- 1
    while (i <= length(names(p))) {
        namepi <- names(p)[i]
        if (!(namepi %in% names(q))) {
            if (p[i] > 0) 
                DIFFp <- DIFFp + p[i] * log2(p[i]/EPSILON)
            p <- p[-i]
            i <- 0
        }
        i <- i + 1
    }
    DIFFq <- 0
    i <- 1
    while (i <= length(names(q))) {
        nameqi <- names(q)[i]
        if (!(nameqi %in% names(p))) {
            if (q[i] > 0) 
                DIFFq <- DIFFq + q[i] * log2(q[i]/EPSILON)
            q <- q[-i]
            i <- 0
        }
        i <- i + 1
    }
    if (length(p) > 0 & length(q) > 0) {
        q <- q[names(p)]
        p <- p + EPSILON
        p <- p/sum(p)
        q <- q + EPSILON
        q <- q/sum(q)
        kldivergence <- min(sum(p * log2(p/q)) + DIFFp, sum(q * 
            log2(q/p)) + DIFFq)
    }
    else kldivergence <- min(DIFFp, DIFFq)
    return(kldivergence)
}
