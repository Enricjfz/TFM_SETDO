inst.table.decision <-
function (id, INSTANCES = NULL, trz.tables = FALSE) 
{
    DECISIONS <- decisions(id, names(id), trz.definition = trz.tables)
    for (i in 1:length(DECISIONS)) {
        sink(paste(idr.output.eval(), DECISIONS[i], ".itd", sep = ""))
        cat("; Table Instances, one by row, canonical base\n")
        if (length(INSTANCES) == 0) 
            cat(-1, ";\n")
        else for (j in 1:length(INSTANCES[, 1])) {
            stream.token(INSTANCEs[j, ], tksep = " ")
            cat(" ;\n")
        }
        sink()
    }
    return(DECISIONS)
}
