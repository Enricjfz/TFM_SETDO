matrix.datax <-
function (id, node, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("matrix.datax ")
    a <- NULL
    if (!is.decision(node)) 
        if (is.matrix(node$pots)) {
            if (is.chance(node)) {
                a <- array(data = as.vector(t(node$pots)), dim = rev(Dim(id, 
                  node$preds)), dimnames = c(node$preds, node$name))
            }
            if (is.utility(node)) {
                a <- array(data = as.vector(t(node$pots)), dim = rev(Dim(id, 
                  node$preds)), dimnames = node$preds)
            }
        }
        else stop("( a == NULL)")
    if (trz.probability) 
        cat("matrix.datax: OK\n")
    return(a)
}
