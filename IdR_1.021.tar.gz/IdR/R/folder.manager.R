folder.manager <-
function () 
{
    wd <- getwd()
    fp <- file.path(wd, idr.output.eval())
    ifelse(!dir.exists(fp), dir.create(fp), {
        k <- 1
        if (dir.exists(paste(wd, "/", idr.output.eval("No"), 
            sep = ""))) 
            while (dir.exists(paste(wd, "/", idr.output.eval("No"), 
                "_", k, sep = ""))) k <- k + 1
        system(paste("mv ", sprintf("%s ", fp), sprintf(" %s", 
            paste(wd, "/", idr.output.eval("No"), "_", k, sep = ""))))
        dir.create(fp)
    })
}
