dump.tdu <-
function (id, CALC = TRUE, node.D, node.U, Params = NULL, trz.primitive = FALSE) 
{
    prefix.eq <- ""
    header.tdu <- function(id, node.D) {
        sink(paste(idr.output.eval(), prefix.eq, node.D$name, 
            ".hkb", sep = ""))
        cat("File: ", paste(prefix.eq, node.D$name, sep = ""), 
            ".txt ; \n", sep = "")
        cat("Head:", length(node.D$values), 1, length(node.D$preds), 
            " ;rst\n")
        cat("R: ", paste(length(node.D$preds) + (1:length(node.D$values))), 
            " ;\n")
        cat("S: ", length(node.D$preds), " ;\n")
        cat("T: ", 0:(length(node.D$preds) - 1), " ;\n")
        cat("Dom: ")
        for (i in 1:length(node.D$preds)) cat(length(ann(id, 
            node.D$preds[i])$values), " ")
        cat(" ;\n")
        cat("Bas: ")
        for (i in 1:length(node.D$preds)) cat((i - 1), " ")
        cat(" ;\n")
        cat("Rol: ")
        for (i in 1:length(node.D$preds)) cat((-1), " ")
        cat(" ;")
        sink()
        return("rst")
    }
    if (trz.primitive) 
        cat("file.tdu ")
    lpreds <- length(node.U$preds) - 1
    if (node.U$preds[length(node.U$preds)] != node.D$name) 
        node.U <- rotacion.pots(id, node.U, c(node.D$name))
    if (length(node.U$preds) > 0) {
        if (trz.primitive) 
            cat("sink: ", paste(idr.output.eval(), prefix.eq, 
                node.D$name, ".eq", sep = ""), " ")
        sink(paste(idr.output.eval(), prefix.eq, node.D$name, 
            ".eq", sep = ""))
        cat(";Decision: ", node.D$name, "\n;Preds utility node: ", 
            node.U$name, " <", node.U$preds, ">\n")
        cat("File: ", paste("dec-", node.D$name, sep = ""), ";\n")
        cat("S: ", (10 * node.D$pots[1]), node.D$name, length(node.D$values), 
            ";\n")
        cat("Val: ", node.D$values, ";\n")
        if (lpreds > 0) 
            for (i in 1:lpreds) {
                node <- ann(id, node.U$preds[i])
                cat("Att: ", (100 * node.D$pots[1] * (i + 1)), 
                  node.U$preds[i], length(node$values), ";\n")
                cat("Val: ", node$values, ";\n")
            }
        else {
            cat("Att: ", (100 * node.D$pots[1] * (1)), "-", "-", 
                ";\n")
            cat("Val: ", "-", ";\n")
        }
        sink()
    }
    else {
        cat("Error: file.tdu\n")
        cat("Decision node: ", node.D$name, "\n")
        return(node.U$name)
    }
    cat("Decision node: ", node.D$name, "\n")
    if (CALC) {
        write.table("///\n***", file = paste(idr.output.eval(), 
            prefix.eq, node.D$name, "-.tdu", sep = ""), append = FALSE, 
            quote = FALSE, sep = "\t", eol = "\n", dec = ".", 
            row.names = FALSE, col.names = FALSE)
        utility.vector <- as.vector(round(node.U$pots, digits = 5))
        utility.matrix <- matrix(data = utility.vector, byrow = TRUE, 
            ncol = length(node.D$values))
        utility.data.frame <- data.frame(utility.matrix, rep(";", 
            length(utility.matrix[, 1])))
        write.table(utility.data.frame, file = paste(idr.output.eval(), 
            prefix.eq, node.D$name, "-.tdu", sep = ""), append = TRUE, 
            quote = FALSE, sep = "\t", eol = "\n", dec = ".", 
            row.names = FALSE, col.names = FALSE)
        Grid <- mdgrid(id, node.U)
        utl <- length(node.U$pots[, 1])
        if (length(Params$var) > 0) {
            GRID <- data.frame(Grid, rep(Params$p[1], utl))
            for (k in 2:length(Params$var)) GRID <- data.frame(GRID, 
                rep(Params$p[k], utl))
        }
        else GRID <- data.frame(Grid, round(node.U$pots, digits = 7))
        names(GRID) <- c(names(Grid), Params$var, "Utility")
        file.name <- paste(idr.output.eval(), prefix.eq, node.D$name, 
            ".txt", sep = "")
        write(file = file.name, append = FALSE, paste("; ", names(GRID), 
            sep = ""))
        write(file = file.name, append = TRUE, paste("\n", sep = ","))
        write(file = file.name, append = TRUE, paste(names(GRID), 
            sep = ","))
        write(file = file.name, append = TRUE, paste("\n", sep = ","))
        write.table(GRID, file = file.name, append = TRUE, quote = FALSE, 
            sep = ",", eol = "\n", dec = ".", row.names = FALSE, 
            col.names = FALSE)
    }
    if (trz.primitive) 
        cat("file.tdu: OK\n")
    return(GRID)
}
