lbn.structure <-
function (data, MatrixAdyacency, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# lbn.structure: ")
    NAMES <- names(data)
    domains <- c()
    for (j in 1:dim(data)[2]) {
        dom <- length(names(table(data[, j])))
        if (dom == 1) {
            MatrixAdyacency[j, ] <- 0
            MatrixAdyacency[, j] <- 0
        }
        domains <- c(domains, dom)
    }
    DMAX <- max(domains)
    values <- matrix(data = rep("-", dim(data)[2] * DMAX), nrow = dim(data)[2], 
        byrow = TRUE)
    for (i in 1:dim(data)[2]) {
        names.table <- names(table(data[, i]))
        for (j in 1:domains[i]) values[i, j] <- names.table[j]
    }
    net <- random.network(Nodes = NAMES, Domains = domains, Values = values, 
        max.gr = 3, mady = MatrixAdyacency, Probability = FALSE, 
        trz.definition = trz.probability)
    if (trz.probability) 
        cat("# lbn.structure OK\n")
    return(net)
}
