samnod.eval <-
function (net, name = "netname", numsamples = 30, trz.evaluation = FALSE) 
{
    TIME0 <- proc.time()
    if (trz.evaluation) 
        cat("SAMNOD.EVAL ")
    folder.manager()
    max.gr <- max(apply(mady(net), 2, sum))
    if (max.gr > 3) {
        print("WARNING max.gr > 3. The network will be simplified to grade=3.")
        print(mady(net))
        net <- simple.network <- function(net, node = 0, simple = "IRR", 
            SIMPLE.GR = 3, trz.definition = trz.evaluation) print(mady(net))
    }
    net <- reset.eval(net)
    ssz <- summary.network(net, name = name, verbose = "NO", 
        trz.definition = trz.evaluation)
    lex <- net.lex.tab(net)
    bn.simu <- x3.sbn(net, lex, ssz * numsamples, trz.probability = trz.evaluation)
    if (trz.evaluation) 
        print(bn.simu)
    cat("SAMPLE EVALUATION: ", name, "  size: ", ssz * numsamples, 
        "\n")
    for (i in 1:length(net)) {
        pot <- table(bn.simu[, i])
        pot <- pot/sum(pot)
        net[i][[1]]$mpot = matrix(data = pot, nrow = 1, byrow = TRUE, 
            dimnames = list(c(), names(pot)))
    }
    if (trz.evaluation) 
        cat("SAMNOD.EVAL: OK\n")
    cat("#  proc.time: ", (proc.time() - TIME0)[1], "\n")
    net <- print.eval(net)
    invisible(net)
}
