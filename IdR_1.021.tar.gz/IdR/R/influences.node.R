influences.node <-
function (net, node.j, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<influences.node>")
    RRvector <- rep(0, length(node.j$preds))
    pred <- 1
    for (i.name in node.j$preds) {
        node.i <- ann(net, i.name)
        vals <- length(node.j$values)
        blocks <- length(node.j$pots[, 1])/vals
        node.j <- rotacion.pots(net, node.j, c(node.i$name))
        RRvector[pred] <- relevant(node.j, vals, blocks)
        pred <- pred + 1
    }
    return(RRvector)
}
