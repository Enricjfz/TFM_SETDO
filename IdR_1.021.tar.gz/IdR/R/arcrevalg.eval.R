arcrevalg.eval <-
function (id, name = "netname", CALC = TRUE, ELTOS = 20, DUMP = FALSE, 
    Params = NULL, NumClusters = 2, EU.KL = "EU", trz.evaluation = FALSE) 
{
    traza.rc <- function(id, step.EVAL, i) {
        id <- check.rr(id, trz.evaluation)
        id <- check.mx(id, CALC = CALC, trz.probability = trz.evaluation)
        filename <- paste(step.EVAL, "-rc-", id[i][[1]]$name, 
            "-", "id", ".trz", sep = "")
        save(id, file = filename, ascii = TRUE)
        print(id[i][[1]]$name)
        print(id[i][[1]]$preds)
        if (CALC) {
            print(id[i][[1]]$pots[1:min(length(id[i][[1]]$pots), 
                ELTOS)])
        }
        return(id[i][[1]]$preds)
    }
    traza.U <- function(id, node.U) {
        if (length(id) > 1) 
            print.mady(mady(id))
        cat("node.U...........: ", node.U$name, "   ")
        cat("node.U$preds.....: ", node.U$preds, "\n")
        cat("id.size.real.....: ", id.size.real(id, trz.definition = trz.evaluation), 
            "   ")
        cat("id.size.nominal..: ", id.size.nominal(id, trz.definition = trz.evaluation), 
            "\n")
        if (CALC) {
            print(node.U$pots[1:min(length(node.U$pots), ELTOS)])
        }
        return(node.U$preds)
    }
    if (trz.evaluation) 
        cat("ARCREVALG.EVAL\n")
    TIME0 <- proc.time()
    folder.manager()
    index.protocol.decision(id, trz.tables = trz.evaluation)
    inst.table.decision(id, trz.tables = trz.evaluation)
    if (trz.evaluation) {
        id <- check.rr(id, trz.definition = trz.evaluation)
        id <- check.mx(id, EPSILON = 9.9999999999999995e-08, 
            CALC = CALC, trz.probability = trz.evaluation)
        print.mady(mady(id, trz.definition = trz.evaluation))
    }
    id <- am(id, trz.evaluation = trz.evaluation)
    node.U <- utility.node(id, trz.definition = trz.evaluation)
    if (CALC) {
        cat("node.U$preds: ", node.U$preds, "\n")
        print(node.U$pots[1:min(length(node.U$pots), ELTOS)])
    }
    if (sum(is.na(node.U$pots)) > 0) {
        stop("begin Utility NA!")
    }
    step.EVAL <- 1
    nodeseq <- c()
    nodelist <- c()
    while (length(utility.node(id)$preds) > 0) {
        cat("\n[Step: ", step.EVAL, "]   ")
        cat("id.size.real: ", id.size.real(id, trz.definition = trz.evaluation), 
            "   ")
        cat("id.size.nominal:", id.size.nominal(id, trz.definition = trz.evaluation), 
            "\n")
        if (trz.evaluation) {
            filename <- paste(step.EVAL, "-", name, "-", "id", 
                ".trz", sep = "")
            save(id, file = filename, ascii = TRUE)
            id <- check.rr(id, trz.definition = trz.evaluation)
            id <- check.mx(id, EPSILON = 9.9999999999999995e-08, 
                CALC = CALC, trz.probability = trz.evaluation)
            print.mady(mady(id))
        }
        node.U <- utility.node(id)
        chance <- FALSE
        {
            i <- 1
            while (i <= length(id)) {
                if (is.chance(id[i][[1]])) {
                  if (!trz.evaluation) 
                    cat("\n[try to remove chance node: ", id[i][[1]]$name, 
                      "]\n")
                  MADY <- mady(id)
                  if (MADY[i, index.id(id, node.U$name)] == CONDICIONAL()) {
                    if (sum(MADY[i, ]) == 1) {
                      cat("\n[remove chance node: ", id[i][[1]]$name, 
                        "   preds: ", id[i][[1]]$preds, " OK-1] ***\n")
                      if (trz.evaluation) 
                        traza.rc(id, step.EVAL, i)
                      nodeseq <- c(nodeseq, id[i][[1]]$name)
                      nodelist <- c(nodelist, " Chance node removal ", 
                        id[i][[1]]$name)
                      if (DUMP) {
                        dump.tpc(id, CALC, id[i][[1]], node.U, 
                          NumClusters, EU.KL = EU.KL, trz.primitive = trz.evaluation)
                      }
                      id <- rc(id, id[i][[1]], node.U, CALC = CALC, 
                        trz.evaluation)
                      node.U <- utility.node(id)
                      if (trz.evaluation) 
                        traza.U(id, node.U)
                      chance <- TRUE
                      i <- 0
                    }
                  }
                }
                i <- i + 1
            }
        }
        decision <- FALSE
        if (!chance) {
            for (i in 1:length(id)) {
                if (is.decision(id[i][[1]])) {
                  if (trz.evaluation) 
                    cat("\n[try to remove decision node: ", id[i][[1]]$name, 
                      "]\n")
                  MADY <- mady(id)
                  if (MADY[i, index.id(id, node.U$name)] == 1) {
                    Preds.U <- remove.name(node.U$preds, id[i][[1]]$name)
                    Preds.D <- id[i][[1]]$preds
                    if (esta(Preds.U, Preds.D)) {
                      cat("\n[remove decision node: ", id[i][[1]]$name, 
                        " OK]\n")
                      if (trz.evaluation) {
                        id <- check.rr(id, trz.definition = trz.evaluation)
                        id <- check.mx(id, EPSILON = 9.9999999999999995e-08, 
                          CALC = CALC, trz.probability = trz.evaluation)
                        filename <- paste(step.EVAL, "-rd-", 
                          id[i][[1]]$name, "-", "id", ".trz", 
                          sep = "")
                        save(id, file = filename, ascii = TRUE)
                      }
                      nodeseq <- c(nodeseq, id[i][[1]]$name)
                      nodelist <- c(nodelist, " Decision node removal ", 
                        id[i][[1]]$name)
                      if (DUMP) {
                        dump.tdu(id, CALC, id[i][[1]], node.U, 
                          Params, trz.primitive = trz.evaluation)
                      }
                      id <- rd(id, id[i][[1]], node.U, CALC = CALC, 
                        trz.evaluation)
                      node.U <- utility.node(id)
                      if (trz.evaluation) 
                        traza.U(id, node.U)
                      decision <- TRUE
                      break
                    }
                  }
                }
            }
        }
        if (!decision & !chance) {
            for (i in 1:length(id)) {
                MADY <- mady(id)
                if (is.chance(id[i][[1]])) {
                  if (MADY[i, index.id(id, node.U$name)] == CONDICIONAL()) {
                    if (prod(MADY[i, (MADY[i, ] > 0)]) == 1) {
                      if (trz.evaluation) 
                        cat("\n[try to reversal arc from: ", 
                          id[i][[1]]$name, "  preds: ", id[i][[1]]$preds, 
                          "]\n")
                      while (sum(MADY[i, ]) > 1) {
                        for (j in 1:length(id)) {
                          if (!is.utility(id[j][[1]])) {
                            if (MADY[i, j] == CONDICIONAL()) {
                              cat("\n[reversal arc to: ", id[j][[1]]$name, 
                                "  preds:", id[i][[1]]$preds, 
                                "OK]\n")
                              if (trz.evaluation) {
                                id <- check.rr(id, trz.definition = trz.evaluation)
                                id <- check.mx(id, EPSILON = 9.9999999999999995e-08, 
                                  CALC = CALC, trz.probability = trz.evaluation)
                                filename <- paste(step.EVAL, 
                                  "-ia-", id[i][[1]]$name, "x---x", 
                                  id[j][[1]]$name, "-", "id", 
                                  ".trz", sep = "")
                                save(id, file = filename, ascii = TRUE)
                                if (CALC) {
                                  cat("node.j: ", id[j][[1]]$name, 
                                    "  PREDS:", id[j][[1]]$preds, 
                                    "\n")
                                  print(id[j][[1]]$pots[1:min(length(id[j][[1]]$pots[, 
                                    1]), ELTOS), ])
                                  cat("node.i: ", id[i][[1]]$name, 
                                    "  PREDS:", id[i][[1]]$preds, 
                                    "\n")
                                  print(id[i][[1]]$pots[1:min(length(id[i][[1]]$pots[, 
                                    1]), ELTOS), ])
                                }
                              }
                              id <- ia(id, id[i][[1]], id[j][[1]], 
                                CALC = CALC, trz.evaluation)
                              if (mady(id)[j, i] == CONDICIONAL()) 
                                nodelist <- c(nodelist, " Arc reversal ", 
                                  id[i][[1]]$name, id[j][[1]]$name)
                              if (trz.evaluation) {
                                cat("id.size.real: ", id.size.real(id), 
                                  "   ")
                                cat("id.size.nominal:", id.size.nominal(id), 
                                  "\n")
                                if (CALC) {
                                  cat("node.j: ", id[j][[1]]$name, 
                                    "  PREDS:", id[j][[1]]$preds, 
                                    "\n")
                                  print(id[j][[1]]$pots[1:min(length(id[j][[1]]$pots[, 
                                    1]), ELTOS), ])
                                  cat("node.i: ", id[i][[1]]$name, 
                                    "  PREDS:", id[i][[1]]$preds, 
                                    "\n")
                                  print(id[i][[1]]$pots[1:min(length(id[i][[1]]$pots[, 
                                    1]), ELTOS), ])
                                }
                              }
                            }
                          }
                          MADY <- mady(id)
                        }
                      }
                      cat("\n[remove chance node: ", id[i][[1]]$name, 
                        "  preds: ", id[i][[1]]$preds, " OK-2] ***\n")
                      if (trz.evaluation) 
                        traza.rc(id, step.EVAL, i)
                      nodeseq <- c(nodeseq, id[i][[1]]$name)
                      nodelist <- c(nodelist, " Chance node removal ", 
                        id[i][[1]]$name)
                      if (DUMP) {
                        dump.tpc(id, CALC, id[i][[1]], node.U, 
                          NumClusters, EU.KL = EU.KL, trz.primitive = trz.evaluation)
                      }
                      id <- rc(id, id[i][[1]], node.U, CALC = CALC, 
                        trz.evaluation)
                      node.U <- utility.node(id)
                      if (trz.evaluation) 
                        traza.U(id, node.U)
                      break
                    }
                  }
                }
            }
        }
        step.EVAL <- step.EVAL + 1
    }
    if (trz.evaluation) 
        cat("REMARC.EVAL: OK\n")
    if (CALC) 
        print(node.U$pots[, 1])
    if (sum(is.na(node.U$pots[1])) > 0) {
        stop("end Utility NA!")
    }
    print(proc.time() - TIME0)
    return(list(node.seq = c(nodeseq, node.U$name), op.seq = c(nodelist, 
        node.U$name)))
}
