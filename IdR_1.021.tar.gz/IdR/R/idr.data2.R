idr.data2 <-
function () 
{
    setwd("models/IDmodels")
    source("nhlv2.r")
    source("ictneo2HGM.r")
    setwd("../..")
    print("DATA2 IdR ok")
}
