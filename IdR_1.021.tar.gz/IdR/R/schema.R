schema <-
function (net, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<schema")
    Schema <- c()
    for (i in 1:length(net)) {
        if (is.decision(id[i][[1]])) 
            if (!(net[i][[1]]$name %in% Schema)) 
                Schema <- c(Schema, net[i][[1]]$name)
    }
    for (i in 1:length(net)) {
        if (is.utility(net[i][[1]])) 
            if (!(net[i][[1]]$name %in% Schema)) 
                Schema <- c(Schema, net[i][[1]]$name)
    }
    for (i in 1:length(net)) {
        if (is.chance(net[i][[1]])) 
            if (!(net[i][[1]]$name %in% Schema)) 
                Schema <- c(Schema, net[i][[1]]$name)
    }
    for (i in 1:length(net)) {
        if (is.deterministic(net[i][[1]])) 
            if (!(net[i][[1]]$name %in% Schema)) 
                Schema <- c(Schema, net[i][[1]]$name)
    }
    if (length(net) != length(Schema)) 
        stop("length( net) != length( Schema)")
    if (trz.definition) 
        cat("-schema>")
    return(Schema)
}
