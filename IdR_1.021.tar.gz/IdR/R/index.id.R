index.id <-
function (id, nodename, trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<index.id")
    for (i in 1:length(id)) {
        if (id[i][[1]]$name == nodename) {
            if (trz.definition) 
                cat("-index.id>\n")
            return(c(i))
        }
    }
    cat("Error, non exist nodename: ", nodename, "\n")
    print(names(id))
    stop("Error index.id")
}
