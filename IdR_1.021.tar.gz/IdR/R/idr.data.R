idr.data <-
function () 
{
    setwd("models/BNmodels")
    source("asia.r")
    source("bayes2.r")
    source("bayes3.r")
    source("bayes5.r")
    setwd("../..")
    setwd("models/IDmodels")
    source("dam.r")
    source("server.r")
    source("bypass.r")
    source("helicopter.r")
    source("underground.r")
    source("treatment.r")
    setwd("../..")
    print("DATA IdR ok")
}
