dump.chance <-
function (node) 
{
    if (is.matrix(node$pots) == FALSE) {
        cat("The argument is not a matrix")
        stop("dump.chance")
    }
    cat(node$name, " = node(Type=\"CHANCE\", Name=\"", node$name, 
        sep = "")
    cat("\", Values=c(", stream.token(node$values, quote = TRUE), 
        "), Preds=c(", stream.token(node$preds, quote = TRUE))
    cat("),##\n Pots=matrix( data = c(\n", stream.token(as.vector(t(node$pots)), 
        ncol = dim(node$pots)[2]), "),\n")
    cat("nrow=", dim(node$pots)[1], ", ncol=", dim(node$pots)[2], 
        ", byrow=TRUE, dimnames=NULL)", ")", sep = "")
}
