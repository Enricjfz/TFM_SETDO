u4 <-
function (y5, y6) 
{
    return(return(ux5(y5) + ux6(y6)))
}
