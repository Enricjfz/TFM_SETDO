bntobbn <-
function (net, typePot = c("probabilityfunction", "distributionfunction")[1], 
    trz.definition = FALSE) 
{
    split.node.values <- function(net, node) {
        binaryLinkPot <- function(margprob, numbinpreds = 0) {
            if (numbinpreds == 0) {
                s2 <- sum(margprob[2:length(margprob)])
                return(c(s2, 1 - s2))
            }
            if (numbinpreds == 1 && length(margprob) == 2) 
                return(c(0, 1, 1, 0))
            if (numbinpreds >= 1 && length(margprob) > 2) {
                si <- sum(margprob[(numbinpreds + 1):length(margprob)])
                return(c(1 - margprob[numbinpreds + 1]/si, margprob[numbinpreds + 
                  1]/si, rep(c(1, 0), 2^numbinpreds - 1)))
            }
            if (trz.definition) 
                print(margprob)
            if (trz.definition) 
                print(numbinpreds)
            stop("binaryLinkPot??")
        }
        nodename <- node$name
        binaryPreds <- c()
        cat("SPLIT node values\n")
        for (nodevalue in node$values) {
            cat("SPLIT node  ", nodevalue, "\n")
            NodeName <- paste(nodename, ".", nodevalue, sep = "")
            binaryNode <- node(Type = "CHANCE", Name = NodeName, 
                Values = c(paste("NOT", nodevalue, sep = ""), 
                  nodevalue), Preds = binaryPreds, Pots = stocastic(matrix(data = binaryLinkPot(margprob = as.vector(node$pots), 
                  length(binaryPreds)), nrow = 2^length(binaryPreds), 
                  ncol = 2, byrow = TRUE, dimnames = NULL)), 
                Mpot = NULL, Maxszpot = 0, EPSILON = 1e-25, trz.definition = FALSE)
            print(str(binaryNode))
            binaryPreds <- c(binaryPreds, NodeName)
            if (trz.definition) 
                cat("binaryPreds  ", binaryPreds, "\n")
            if (trz.definition) 
                cat("add binaryNodes !\n")
            net <- c(net, list(as.list(binaryNode)))
            names(net) <- c(names(net)[1:(length(names(net)) - 
                1)], NodeName)
        }
        cat("end SPLIT node values\n")
        return(list(binaryPreds = binaryPreds, net = net))
    }
    setup.conditional.pots <- function(net, node, binaryPreds) {
        binmask <- function(nvalues = 2) {
            binary <- function(i, k) {
                b <- c()
                for (p in k:1) {
                  b[p] <- i%%2
                  i <- i%/%2
                }
                return(b)
            }
            if (nvalues <= 1) 
                stop("nvalues <=1  ", nvalues)
            mask <- matrix(data = rep(0, 2^nvalues * nvalues), 
                nrow = 2^nvalues, ncol = nvalues, byrow = TRUE, 
                dimnames = NULL)
            mask[1, ] <- rep(-1, nvalues)
            for (i in 2:(2^nvalues - 1)) {
                bin <- binary(i - 1, k = nvalues)
                zero <- which(bin == 0)
                if (length(zero) != 0) {
                  z <- 0
                  if (sum(bin) > 1) 
                    z <- -(sum(bin) - 1)/length(zero)
                  bin[zero] <- rep(z, length(zero))
                  mask[i, ] <- bin
                }
            }
            mask[2^nvalues, ] <- rep(-1, nvalues)
            return(mask)
        }
        nodename <- node$name
        nodenames <- names(net)
        for (cnodename in nodenames) {
            cnode <- ann(net, cnodename)
            if (nodename %in% cnode$preds) {
                cat("Setup Conditional Pots, cnodename:", cnodename, 
                  "\n")
                Sorted.preds <- cnode$preds
                if (Sorted.preds[length(Sorted.preds)] != nodename) {
                  i <- which(Sorted.preds == nodename)
                  Sorted.preds <- c(Sorted.preds[(i + 1):(length(Sorted.preds))], 
                    Sorted.preds[1:i])
                }
                cnode <- rotacion.pots(net, cnode, Sorted.preds)
                nvalues <- length(node$values)
                cpots <- cnode$pots
                wv <- weights.vector(net, rev(cnode$preds), trz.probability = trz.definition)
                nbloks <- wv[1]
                cvalues <- length(cnode$values)
                szblok <- 2^nvalues
                BINMASK <- binmask(nvalues = nvalues)
                if (trz.definition) {
                  cat("nvalues  ", nvalues, "\n")
                  cat("cpots:  \n")
                  print(cpots)
                  cat("weights.vector:  \n")
                  print(wv)
                  cat("nbloks  ", nbloks, "\n")
                  cat("cnodename  ", cnodename, "\n")
                  cat("szblok  ", szblok, "\n")
                  cat("BINMASK\n")
                  print(BINMASK)
                }
                POTS <- matrix(data = rep(0, szblok * nbloks * 
                  cvalues), nrow = szblok * nbloks, ncol = cvalues, 
                  byrow = TRUE, dimnames = NULL)
                for (nb in 1:nbloks) {
                  POTS[(nb - 1) * szblok + 1, ] <- rep(1/cvalues, 
                    cvalues)
                  for (k in ((nb - 1) * szblok + 2):((szblok) * 
                    (nb) - 1)) {
                    if (trz.definition) 
                      cat("k ", k, "   BINMASK[ k%%szblok,]:  ")
                    if (trz.definition) 
                      print(BINMASK[k%%szblok, ])
                    if (trz.definition) 
                      print(cpots[((1 + (nb - 1) * nvalues)):(nvalues * 
                        nb), ])
                    POTS[k, ] <- BINMASK[k%%szblok, ] %*% cpots[((1 + 
                      (nb - 1) * nvalues)):(nvalues * nb), ]
                  }
                  POTS[(szblok) * (nb), ] <- rep(1/cvalues, cvalues)
                }
                if (length(cnode$preds) > 1) 
                  cnode$preds <- c(cnode$preds[1:(length(cnode$preds) - 
                    1)], binaryPreds)
                else cnode$preds <- binaryPreds
                cnode$pots <- stocastic(POTS)
                if (trz.definition) {
                  cat("POTS of cnode  \n")
                  print(POTS)
                  cat("cnode$pots:  \n")
                  print(cnode$pots)
                }
                net <- net[-index.id(net, cnode$name, trz.definition)]
                net <- c(net, list(as.list(cnode)))
                names(net) <- c(names(net)[1:(length(names(net)) - 
                  1)], cnode$name)
            }
        }
        cat("end Setup Conditional Pots", cnodename, "\n")
        return(net)
    }
    if (trz.definition) {
        MADY <- mady(net)
        print.mady(MADY)
    }
    cat("network.type: ", network.type(net, trz.definition), 
        "\n")
    if (trz.definition) 
        print(str(net))
    nodenames <- names(net)
    print("bntobbn")
    for (nodename in nodenames) {
        cat("bntobbn, nodename:", nodename, "   .............................................\n")
        if (trz.definition) 
            print(str(net))
        if (trz.definition) 
            print(names(net))
        node <- ann(net, nodename)
        if (trz.definition) 
            print(str(node))
        if (trz.definition) 
            print(names(node))
        if (!is.discrete(node)) {
            print("DISCRETIZATION for continous node")
            i <- index.id(net, nodename, trz.definition)
            net[i][[1]] <- discretizeNode(node, trz.definition)
        }
        node <- ann(net, nodename)
        print(str(node))
        if (!is.marginal(node)) {
            cat("MARGINALIZATION for spliting\n")
            i <- index.id(net, nodename, trz.definition)
            net <- marginalizar(net, i, Marg = "network", trz.evaluation = trz.definition)
        }
        node <- ann(net, nodename)
        if (trz.definition) 
            print(str(node))
        split <- split.node.values(net, node)
        binaryPreds <- split$binaryPreds
        net <- split$net
        if (trz.definition) 
            print(str(net))
        net <- setup.conditional.pots(net, node, binaryPreds)
        cat("remove node !\n")
        net <- net[-index.id(net, nodename, trz.definition)]
        if (trz.definition) 
            print(str(net))
    }
    print("-----------------------------------------------------------")
    binary.net <- bayesian.network.(net, trz.definition = trz.definition)
    print(str(binary.net))
    if (trz.definition) 
        print(names(binary.net))
    c.c(binary.net, 0, "random.network")
    if (trz.definition) {
        MADY <- mady(binary.net)
        print.mady(MADY)
    }
    invisible(binary.net)
}
