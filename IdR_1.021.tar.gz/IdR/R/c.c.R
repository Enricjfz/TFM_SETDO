c.c <-
function (id, node = 0, msg = "ia", trz.definition = FALSE) 
{
    if (trz.definition) 
        cat("<c.c")
    n <- length(id)
    MADY <- mady(id)
    if (node[1] == 0) 
        nodeset <- 1:n
    else nodeset <- node
    for (i in nodeset) if (!(sum(MADY[, i]) == 0)) {
        if (!(sum(MADY[i, ]) == 0)) {
            SUCCS <- MADY[i, ]
            for (k in 1:n) {
                for (j in 1:n) if (SUCCS[j] == CONDICIONAL()) 
                  SUCCS <- (SUCCS + MADY[j, ])
                SUCCS[SUCCS > INDEP.COND_()] <- CONDICIONAL()
                if (SUCCS[i] == CONDICIONAL()) {
                  if (msg != "ia") {
                    sink()
                    cat("\n  c.c: msg --- ", msg, "  i:", i, 
                      "\n")
                    cat("\n  c.c: SUCCS --- ", SUCCS, "\n")
                    cat("cicle: node ", id[i][[1]]$name, "  preds: ", 
                      id[i][[1]]$preds, "\n")
                    cat("cicle: node ", id[i][[1]]$name, "  PREDS: ", 
                      names.id(id, which(SUCCS == 1)), "\n")
                    stop("-c.c!!")
                  }
                  else return(TRUE)
                }
            }
        }
    }
    if (trz.definition) 
        cat("-c.c>")
    return(FALSE)
}
