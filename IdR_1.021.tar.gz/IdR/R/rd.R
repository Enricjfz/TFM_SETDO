rd <-
function (id, node, node.U, CALC = TRUE, trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("rd ")
    node.U <- max.utilidad(id, node, node.U, Calc = CALC, trz.probability = trz.evaluation)
    id[index.id(id, node.U$name)][[1]] <- node.U
    id <- id[c(-index.id(id, node$name))]
    id <- rs(id)
    if (trz.evaluation) 
        cat("rd: OK\n")
    return(id)
}
