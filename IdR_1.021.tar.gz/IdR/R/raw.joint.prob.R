raw.joint.prob <-
function (tab0, correction = 0, trz.probability = FALSE) 
{
    if (trz.probability) 
        cat("# raw.joint.prob: ")
    tab0.p <- data.frame(tab0[1, ], fr = c(1), key = config.key(tab0[1, 
        1:(dim(tab0)[2])]))
    for (i in 2:dim(tab0)[1]) {
        regs <- tab0.p[tab0.p[, 1] == tab0[i, 1], ]
        for (k in 2:dim(tab0)[2]) if (length(regs[, 1]) != 0) 
            regs <- regs[regs[, k] == tab0[i, k], ]
        if (length(regs[, 1]) == 0) 
            tab0.p <- rbind(tab0.p, data.frame(tab0[i, ], fr = c(1), 
                key = config.key(tab0[i, 1:(dim(tab0)[2])])))
        if (length(regs[, 1]) != 0) {
            bcond <- TRUE
            for (k in 1:dim(tab0)[2]) bcond <- bcond & (tab0.p[, 
                k] == regs[1, k])
            index <- which(bcond)
            tab0.p[index, ]$fr <- tab0.p[index, ]$fr + 1
        }
    }
    if (correction > 0) 
        tab0.p$fr <- (tab0.p$fr - 1)/(length(tab0[, 1]) - correction)
    else tab0.p$fr <- tab0.p$fr/length(tab0[, 1])
    if (trz.probability) 
        write.table(tab0.p, file = paste("txt/", "joint-prob-", 
            sample(0:9, 1), sample(0:9, 1), sample(0:9, 1), sample(0:9, 
                1), sample(0:9, 1), ".txt", sep = ""), append = FALSE, 
            quote = FALSE, sep = " ", eol = "\n", na = "NA", 
            dec = ".", row.names = FALSE, col.names = TRUE, qmethod = c("escape", 
                "double"))
    if (trz.probability) 
        cat("# raw.joint.prob OK\n")
    return(tab0.p)
}
