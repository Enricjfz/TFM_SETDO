ann <-
function (id, name, trz.definition = FALSE, STOP = TRUE) 
{
    if (trz.definition) 
        cat("<ann")
    if (name %in% names(id)) 
        return(id[name][[1]])
    if (STOP) {
        cat("Error, ann, non exist node: ", name, "\n")
        print(str(id))
        stop("ann( id, name)")
    }
    return(NULL)
}
