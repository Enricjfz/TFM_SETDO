inv.marginal <-
function (net, i, CALC = TRUE, simple = "IRR", trz.evaluation = FALSE) 
{
    if (trz.evaluation) 
        cat("inv.marginal ")
    Succs <- names(net)[rep(1, length(net)) == mady(net)[i, ]]
    cat("Succs:  ", Succs, "\n")
    cat("Preds:  ", net[i][[1]]$preds, "\n")
    for (name in Succs) {
        node.j <- ann(net, name)
        net <- ia(net, net[i][[1]], node.j)
        net <- network.simple(net, index.id(net, net[i][[1]]$name), 
            simple)
        net <- network.simple(net, index.id(net, node.j$name), 
            simple)
    }
    Succs <- names(net)[rep(1, length(net)) == mady(net)[i, ]]
    cat("Succs:  ", Succs, "\n")
    cat("Preds:  ", net[i][[1]]$preds, "\n")
    if (trz.evaluation) 
        cat("inv.marginal: OK\n")
    return(net)
}
